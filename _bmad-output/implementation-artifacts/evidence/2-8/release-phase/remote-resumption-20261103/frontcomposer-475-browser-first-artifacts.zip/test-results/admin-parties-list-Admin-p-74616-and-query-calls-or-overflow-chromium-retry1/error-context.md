# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: admin-parties-list.spec.ts >> Admin parties list >> direct GDPR route opens operations destination without browser-visible command/query calls or overflow
- Location: specs/admin-parties-list.spec.ts:185:3

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByLabel('Party detail').locator('fluent-dialog').filter({ has: getByRole('dialog', { name: 'Erase party' }) }).getByTestId('fc-destructive-dialog')
Expected: 1
Received: 0
Timeout:  10000ms

Call log:
  - Expect "toHaveCount" getByLabel('Party detail').locator('fluent-dialog').filter({ has: getByRole('dialog', { name: 'Erase party' }) }).getByTestId('fc-destructive-dialog') with timeout 10000ms
  - waiting for getByLabel('Party detail').locator('fluent-dialog').filter({ has: getByRole('dialog', { name: 'Erase party' }) }).getByTestId('fc-destructive-dialog')
    24 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: /admin/parties/grace-hopper/gdpr#fc-main-content
  - generic [ref=e5]:
    - banner [ref=e6]:
      - generic [ref=e7]:
        - generic [ref=e8]:
          - button "Toggle navigation" [ref=e11] [cursor=pointer]
          - generic [ref=e15]: Hexalith FrontComposer
        - generic [ref=e16]:
          - 'button "Change theme: Light" [ref=e18] [cursor=pointer]':
            - generic [ref=e19]:
              - generic:
                - generic [ref=e20]: "Change theme: Light"
                - generic [aria-hidden] [ref=e21]: Light
          - button "Open command palette" [ref=e25] [cursor=pointer]
          - button "Open settings" [ref=e29] [cursor=pointer]
          - button "AE" [ref=e34] [cursor=pointer]
    - generic [ref=e36]:
      - status [ref=e37]
      - main "Main content" [ref=e38]:
        - status [ref=e39]
        - status [ref=e40]
        - region [ref=e42]:
          - generic [ref=e43]:
            - heading "Parties" [level=1] [ref=e45]
            - status [ref=e46]: Parties loaded
          - generic [ref=e47]:
            - generic [ref=e48]:
              - generic: Search
              - generic "Search" [ref=e50]:
                - searchbox "Search parties" [ref=e52]
            - generic [ref=e53]:
              - generic: Party type
              - generic "Party type" [ref=e55] [cursor=pointer]:
                - combobox "Party type" [ref=e57]: All types
            - generic [ref=e61]:
              - generic: Active state
              - generic "Active state" [ref=e63] [cursor=pointer]:
                - combobox "Active state" [ref=e65]: All states
            - generic [ref=e69]:
              - generic: Created after
              - generic "Created after" [ref=e71]:
                - textbox "Created after" [ref=e73]:
                  - /placeholder: YYYY-MM-DD
            - generic [ref=e74]:
              - generic: Created before
              - generic "Created before" [ref=e76]:
                - textbox "Created before" [ref=e78]:
                  - /placeholder: YYYY-MM-DD
            - generic [ref=e79]:
              - generic: Modified after
              - generic "Modified after" [ref=e81]:
                - textbox "Modified after" [ref=e83]:
                  - /placeholder: YYYY-MM-DD
            - generic [ref=e84]:
              - generic: Modified before
              - generic "Modified before" [ref=e86]:
                - textbox "Modified before" [ref=e88]:
                  - /placeholder: YYYY-MM-DD
            - button "Create party" [ref=e89] [cursor=pointer]
            - button "Search" [ref=e91] [cursor=pointer]
            - button "Clear" [ref=e93] [cursor=pointer]
          - generic "Search capabilities" [ref=e95]:
            - button "Display name" [disabled] [ref=e96]
            - button "Email" [disabled] [ref=e98]
            - button "Identifier" [disabled] [ref=e100]
          - complementary "Party detail" [ref=e103]:
            - generic [ref=e104]:
              - heading "Grace Hopper" [level=2] [ref=e105]
              - generic [ref=e106]:
                - button "Back to list" [ref=e107] [cursor=pointer]
                - button "Edit" [ref=e109] [cursor=pointer]
                - button "GDPR operations" [ref=e111] [cursor=pointer]
            - status [ref=e114]: Up to date
            - generic [ref=e115]:
              - generic:
                - generic [ref=e116]:
                  - heading [level=3] [ref=e117]:
                    - button "Summary" [expanded] [ref=e118] [cursor=pointer]
                  - region "Summary" [ref=e121]:
                    - generic [ref=e122]:
                      - term [ref=e123]: Type
                      - definition [ref=e124]: Person
                      - term [ref=e125]: Status
                      - definition [ref=e126]:
                        - generic "Active" [ref=e127]
                      - term [ref=e129]: Created
                      - definition [ref=e130]: 6/9/2026 10:00 AM
                      - term [ref=e131]: Modified
                      - definition [ref=e132]: 6/10/2026 10:00 AM
                - generic [ref=e133]:
                  - heading [level=3] [ref=e134]:
                    - button "Person details" [expanded] [ref=e135] [cursor=pointer]
                  - region "Person details" [ref=e138]:
                    - generic [ref=e139]:
                      - term [ref=e140]: First name
                      - definition [ref=e141]: Grace
                      - term [ref=e142]: Last name
                      - definition [ref=e143]: Hopper
                - generic [ref=e144]:
                  - heading [level=3] [ref=e145]:
                    - button "Contact channels" [expanded] [ref=e146] [cursor=pointer]
                  - region "Contact channels" [ref=e149]:
                    - paragraph [ref=e150]: No contact channels
                - generic [ref=e151]:
                  - heading [level=3] [ref=e152]:
                    - button "Identifiers" [expanded] [ref=e153] [cursor=pointer]
                  - region "Identifiers" [ref=e156]:
                    - paragraph [ref=e157]: No identifiers
                - generic [ref=e158]:
                  - heading [level=3] [ref=e159]:
                    - button "Consent records" [expanded] [ref=e160] [cursor=pointer]
                  - region "Consent records" [ref=e163]:
                    - list [ref=e164]:
                      - listitem [ref=e165]: "newsletter: Revoked"
                - generic [ref=e166]:
                  - heading [level=3] [ref=e167]:
                    - button "Restrictions" [expanded] [ref=e168] [cursor=pointer]
                  - region "Restrictions" [ref=e171]:
                    - generic [ref=e172]:
                      - term [ref=e173]: restricted
                      - definition [ref=e174]: "No"
                      - term [ref=e175]: Restricted at
                      - definition [ref=e176]: —
                      - term [ref=e177]: Erased
                      - definition [ref=e178]: "No"
                      - term [ref=e179]: Erased at
                      - definition [ref=e180]: —
                - generic [ref=e181]:
                  - heading [level=3] [ref=e182]:
                    - button "EventStore links" [expanded] [ref=e183] [cursor=pointer]
                  - region "EventStore links" [ref=e186]:
                    - button "EventStore Admin UI unavailable" [disabled] [ref=e189]
                - generic [ref=e191]:
                  - heading [level=3] [ref=e192]:
                    - button "System metadata" [expanded] [ref=e193] [cursor=pointer]
                  - region "System metadata" [ref=e196]:
                    - generic [ref=e197]:
                      - term [ref=e198]: Sort name
                      - definition [ref=e199]: Hopper
                - generic [ref=e200]:
                  - heading [level=3] [ref=e201]:
                    - button "Name history" [expanded] [ref=e202] [cursor=pointer]
                  - region "Name history" [ref=e205]:
                    - paragraph [ref=e206]: No name history
                - generic [ref=e207]:
                  - heading [level=3] [ref=e208]:
                    - button "GDPR operations" [expanded] [ref=e209] [cursor=pointer]
                  - region "GDPR operations" [ref=e212]:
                    - region [ref=e213]:
                      - heading "GDPR operations" [level=3] [ref=e214]
                      - status
                      - generic [ref=e215]:
                        - generic:
                          - generic [ref=e216]:
                            - heading [level=4] [ref=e217]:
                              - button "Operational summary" [expanded] [ref=e218] [cursor=pointer]
                            - region "Operational summary" [ref=e221]:
                              - generic [ref=e222]:
                                - term [ref=e223]: Pending erasure
                                - definition [ref=e224]: "No"
                                - term [ref=e225]: Restricted party
                                - definition [ref=e226]: "No"
                                - term [ref=e227]: Consent records
                                - definition [ref=e228]: "1"
                                - term [ref=e229]: Audit trail
                                - definition [ref=e230]: "1"
                          - generic [ref=e231]:
                            - heading [level=4] [ref=e232]:
                              - button "Request erasure" [expanded] [ref=e233] [cursor=pointer]
                            - region "Request erasure" [ref=e236]:
                              - generic [ref=e238]:
                                - generic "Erase party":
                                  - dialog "Erase party" [ref=e239]:
                                    - generic [ref=e240]:
                                      - generic [ref=e241]: Erase party
                                      - generic [ref=e245]:
                                        - paragraph [ref=e246]: Erasure destroys protected party data and starts irreversible verification.
                                        - generic [ref=e247]:
                                          - generic: Type the selected party display name
                                          - generic "Type the selected party display name" [active] [ref=e249]:
                                            - textbox "Type the selected party display name" [ref=e251]
                                        - paragraph [ref=e252]: The Erase action stays disabled until the typed value exactly matches the selected party display name.
                                        - status
                                      - generic [ref=e254]:
                                        - button "Cancel" [ref=e255] [cursor=pointer]
                                        - button "Erase" [disabled] [ref=e257]
                                - button "Refresh erasure status" [ref=e259] [cursor=pointer]
                                - status [ref=e261]: Blocked on accepted EventStore-fronted Parties client/gateway contract
                                - paragraph [ref=e262]: "Correlation id: corr-revoke-consent"
                                - button "EventStore Admin UI unavailable" [disabled] [ref=e263]
                          - generic [ref=e265]:
                            - heading [level=4] [ref=e266]:
                              - button "Erasure status" [expanded] [ref=e267] [cursor=pointer]
                            - region "Erasure status" [ref=e270]:
                              - generic:
                                - paragraph [ref=e271]: Certificate unavailable
                                - region [ref=e272]:
                                  - heading "Erasure certificate" [level=5] [ref=e274]
                                  - status [ref=e275]: Verification not yet available
                                  - paragraph [ref=e276]: The erasure status remains available. Certificate verification will appear here when the backend contract is enabled.
                          - generic [ref=e277]:
                            - heading [level=4] [ref=e278]:
                              - button "Restrictions" [expanded] [ref=e279] [cursor=pointer]
                            - region "Restrictions" [ref=e282]:
                              - generic [ref=e284]:
                                - generic [ref=e285]:
                                  - generic: Restriction reason
                                  - generic "Restriction reason" [ref=e287]:
                                    - textbox "Restriction reason" [ref=e289]: contains-sensitive-operator-note
                                - generic [ref=e290]:
                                  - button "Restrict processing" [ref=e291] [cursor=pointer]
                                  - button "Lift restriction" [disabled] [ref=e293]
                          - generic [ref=e295]:
                            - heading [level=4] [ref=e296]:
                              - button "Consent records" [expanded] [ref=e297] [cursor=pointer]
                            - region "Consent records" [ref=e300]:
                              - generic [ref=e302]:
                                - generic [ref=e303]:
                                  - generic [ref=e304]:
                                    - generic: Channel id
                                    - generic "Channel id" [ref=e306]:
                                      - textbox "Channel id" [ref=e308]: news-email
                                  - generic [ref=e309]:
                                    - generic: Purpose
                                    - generic "Purpose" [ref=e311]:
                                      - textbox "Purpose" [ref=e313]: newsletter
                                  - generic [ref=e314]:
                                    - generic: Lawful basis
                                    - generic "Lawful basis" [ref=e316] [cursor=pointer]:
                                      - combobox "Lawful basis" [ref=e318]: Consent
                                  - button "Add consent" [ref=e322] [cursor=pointer]
                                - list [ref=e324]:
                                  - listitem [ref=e325]:
                                    - text: "newsletter: Consent (Revoked)"
                                    - generic [ref=e326]:
                                      - term [ref=e327]: Changed at
                                      - definition: 6/10/2026 10:00 AM
                                      - term [ref=e328]: Revoked
                                      - definition: 6/10/2026 10:00 AM
                          - generic [ref=e329]:
                            - heading [level=4] [ref=e330]:
                              - button "Export party data" [expanded] [ref=e331] [cursor=pointer]
                            - region "Export party data" [ref=e334]:
                              - button "Export party data" [ref=e337] [cursor=pointer]
                          - generic [ref=e339]:
                            - heading [level=4] [ref=e340]:
                              - button "Processing activity records" [expanded] [ref=e341] [cursor=pointer]
                            - region "Processing activity records" [ref=e344]:
                              - generic [ref=e346]:
                                - button "Processing records" [ref=e347] [cursor=pointer]
                                - list [ref=e349]:
                                  - listitem [ref=e350]:
                                    - strong [ref=e351]: GdprOperationRecorded
                                    - generic [ref=e352]:
                                      - term [ref=e353]: Party id
                                      - definition: grace-hopper
                                      - term [ref=e354]: Tenant id
                                      - definition: test-tenant
                                      - term [ref=e355]: Sequence number
                                      - definition: "1"
                                      - term [ref=e356]: Event type
                                      - definition: GdprOperationRecorded
                                      - term [ref=e357]: Operation category
                                      - definition: Read
                                      - term [ref=e358]: Timestamp
                                      - definition: 6/10/2026 10:00 AM
                                      - term [ref=e359]: Actor id
                                      - definition: admin-e2e
                                      - term [ref=e360]: Correlation id
                                      - definition: corr-gdpr-e2e
                                      - term [ref=e361]: Outcome
                                      - definition: Completed
                                      - term [ref=e362]: Summary
                                      - definition: Bounded GDPR operation record
    - generic [ref=e363]: Hexalith FrontComposer © 2026
```

# Test source

```ts
  203 |     await expect(detail.locator('h3[data-primary-destination="gdpr"]')).toBeFocused();
  204 |     await expect.poll(async () => (await latestDetailRequest(request))?.partyId).toBe('grace-hopper');
  205 |     await expect(portalAction(detail, 'Request erasure')).toBeEnabled();
  206 |     await expect(detail.getByRole('button', { name: 'Refresh erasure status' })).toBeEnabled();
  207 |     await expect(detail.getByRole('button', { name: 'Restrict processing' })).toBeEnabled();
  208 |     await expect(portalAction(detail, 'Export party data')).toBeEnabled();
  209 |     await expect(portalAction(detail, 'Processing records')).toBeEnabled();
  210 |     await expect(detail.getByRole('button', { name: 'Retry verification' })).toHaveCount(0);
  211 |     await expect(detail.getByText('Certificate unavailable')).toBeVisible();
  212 |     await expect(detail.getByText('Blocked on accepted EventStore-fronted Parties client/gateway contract')).toBeVisible();
  213 | 
  214 |     await detail.getByRole('textbox', { name: 'Channel id', exact: true }).fill('news-email');
  215 |     await detail.getByRole('textbox', { name: 'Purpose', exact: true }).fill('newsletter');
  216 |     await expect(detail.getByRole('button', { name: 'Add consent' })).toBeEnabled();
  217 |     await detail.getByRole('textbox', { name: 'Restriction reason', exact: true }).fill('contains-sensitive-operator-note');
  218 | 
  219 |     await portalAction(detail, 'Processing records').click();
  220 |     await expect(detail.getByRole('status').filter({ hasText: 'Operation completed' })).toBeVisible();
  221 |     await expect(detail.getByRole('definition').filter({ hasText: /^GdprOperationRecorded$/ })).toBeVisible();
  222 | 
  223 |     await page.evaluate(() => {
  224 |       document.documentElement.style.zoom = '2';
  225 |     });
  226 | 
  227 |     await detail.getByRole('button', { name: 'Restrict processing' }).click();
  228 |     const restrictConfirmation = detail.getByRole('group', { name: 'Confirm restriction' });
  229 |     await expect(restrictConfirmation).toBeVisible();
  230 |     await expect(restrictConfirmation.getByRole('status')).toHaveText('Confirmation opened.');
  231 |     await expect(page.getByRole('dialog')).toHaveCount(0);
  232 |     await expect(detail.getByText('Restrict processing for the selected party?')).toBeVisible();
  233 |     await expect(detail.getByText('contains-sensitive-operator-note')).toHaveCount(0);
  234 |     await detail.getByRole('button', { name: 'Cancel' }).click();
  235 |     await expect(restrictConfirmation).toHaveCount(0);
  236 |     await expect.poll(async () => (await latestRestrictionRequest(request))?.partyId ?? null).toBe(null);
  237 |     await expect.poll(async () => (await gdprRequestCounts(request)).restriction).toBe(0);
  238 | 
  239 |     await detail.getByRole('button', { name: 'Restrict processing' }).click();
  240 |     await expect(detail.getByRole('group', { name: 'Confirm restriction' })).toBeVisible();
  241 |     await detail.getByRole('group', { name: 'Confirm restriction' }).getByRole('button', { name: 'Confirm' }).click();
  242 |     await expect(detail.getByRole('status').filter({ hasText: 'Saved - updating...' })).toBeVisible();
  243 |     await expect(detail.locator('.party-state-badge', { hasText: 'Restricted' })).toBeVisible();
  244 |     await expect.poll(async () => (await latestRestrictionRequest(request))?.partyId).toBe('grace-hopper');
  245 |     await expect.poll(async () => (await gdprRequestCounts(request)).restriction).toBe(1);
  246 |     expect(JSON.stringify(await requestSnapshot(request))).not.toContain('contains-sensitive-operator-note');
  247 |     await expect(detail.getByText('contains-sensitive-operator-note')).toHaveCount(0);
  248 | 
  249 |     await detail.getByRole('button', { name: 'Lift restriction' }).click();
  250 |     const liftConfirmation = detail.getByRole('group', { name: 'Confirm lift restriction' });
  251 |     await expect(liftConfirmation).toBeVisible();
  252 |     await expect(liftConfirmation.getByRole('status')).toHaveText('Confirmation opened.');
  253 |     await expect(page.getByRole('dialog')).toHaveCount(0);
  254 |     await detail.getByRole('button', { name: 'Cancel' }).click();
  255 |     await expect(liftConfirmation).toHaveCount(0);
  256 |     await expect.poll(async () => (await latestLiftRestrictionRequest(request))?.partyId ?? null).toBe(null);
  257 |     await expect.poll(async () => (await gdprRequestCounts(request)).liftRestriction).toBe(0);
  258 | 
  259 |     await detail.getByRole('button', { name: 'Lift restriction' }).click();
  260 |     await expect(detail.getByRole('group', { name: 'Confirm lift restriction' })).toBeVisible();
  261 |     await detail.getByRole('group', { name: 'Confirm lift restriction' }).getByRole('button', { name: 'Confirm' }).click();
  262 |     await expect(detail.getByRole('status').filter({ hasText: 'Saved - updating...' })).toBeVisible();
  263 |     await expect(detail.locator('.party-state-badge', { hasText: 'Active' })).toBeVisible();
  264 |     await expect.poll(async () => (await latestLiftRestrictionRequest(request))?.partyId).toBe('grace-hopper');
  265 |     await expect.poll(async () => (await gdprRequestCounts(request)).liftRestriction).toBe(1);
  266 | 
  267 |     await detail.getByRole('button', { name: 'Add consent' }).click();
  268 |     await expect(detail.getByRole('status').filter({ hasText: 'Saved - updating...' })).toBeVisible();
  269 |     await expect.poll(async () => (await latestAddConsentRequest(request))?.partyId).toBe('grace-hopper');
  270 |     await expect.poll(async () => (await gdprRequestCounts(request)).addConsent).toBe(1);
  271 |     await expect(detail.getByRole('button', { name: 'Revoke consent' })).toBeVisible();
  272 |     await detail.getByRole('button', { name: 'Revoke consent' }).click();
  273 |     const revokeConfirmation = detail.getByRole('group', { name: 'Confirm revoke consent' });
  274 |     await expect(revokeConfirmation).toBeVisible();
  275 |     await expect(revokeConfirmation.getByRole('status')).toHaveText('Confirmation opened.');
  276 |     await expect(page.getByRole('dialog')).toHaveCount(0);
  277 |     await detail.getByRole('button', { name: 'Cancel' }).click();
  278 |     await expect(revokeConfirmation).toHaveCount(0);
  279 |     await expect.poll(async () => (await latestRevokeConsentRequest(request))?.partyId ?? null).toBe(null);
  280 |     await expect.poll(async () => (await gdprRequestCounts(request)).revokeConsent).toBe(0);
  281 |     await detail.getByRole('button', { name: 'Revoke consent' }).click();
  282 |     await expect(detail.getByRole('group', { name: 'Confirm revoke consent' })).toBeVisible();
  283 |     await detail.getByRole('group', { name: 'Confirm revoke consent' }).getByRole('button', { name: 'Confirm' }).click();
  284 |     await expect(detail.getByRole('status').filter({ hasText: 'Saved - updating...' })).toBeVisible();
  285 |     await expect.poll(async () => (await latestRevokeConsentRequest(request))?.partyId).toBe('grace-hopper');
  286 |     await expect.poll(async () => (await gdprRequestCounts(request)).revokeConsent).toBe(1);
  287 | 
  288 |     await expect(portalAction(detail, 'Request erasure')).toBeVisible();
  289 |     await portalAction(detail, 'Request erasure').click();
  290 | 
  291 |     const eraseDialog = page.getByRole('dialog', { name: 'Erase party' });
  292 |     const eraseDialogContent = detail.locator('fluent-dialog').filter({ has: eraseDialog });
  293 |     await expect(eraseDialogContent).toHaveCount(1);
  294 |     await expect(eraseDialog).toBeVisible();
  295 |     await expect(eraseDialog).toHaveAttribute('aria-modal', 'true');
  296 |     const labelledBy = await eraseDialog.getAttribute('aria-labelledby');
  297 |     if (!labelledBy) {
  298 |       throw new Error('Erase dialog must be labelled by its accessible title.');
  299 |     }
  300 |     await expect(page.locator(`#${labelledBy}`)).toHaveText('Erase party');
  301 |     await expect(page.getByRole('dialog')).toHaveCount(1);
  302 |     await qualifyFrontComposerAssets(page);
> 303 |     await expect(eraseDialogContent.getByTestId('fc-destructive-dialog')).toHaveCount(1);
      |                                                                           ^ Error: expect(locator).toHaveCount(expected) failed
  304 |     const warning = eraseDialogContent.locator('p[id^="erasure-warning-"], #fc-destructive-dialog-description');
  305 |     await expect(warning).toBeVisible();
  306 |     await expect(warning).toContainText('irreversible verification');
  307 |     const typedConfirmInput = eraseDialogContent.getByRole('textbox', { name: 'Type the selected party display name', exact: true });
  308 |     await expect(eraseDialogContent.getByRole('button', { name: 'Cancel', exact: true })).toBeFocused();
  309 |     const describedBy = await typedConfirmInput.getAttribute('aria-describedby');
  310 |     if (describedBy) {
  311 |       await expect(page.locator(`#${describedBy}`)).toContainText('irreversible verification');
  312 |     } else {
  313 |       // V5 shadow controls can reference a light-DOM warning through ARIA element reflection.
  314 |       // Require the actual element relationship as well as its accessible description below.
  315 |       const descriptions = await typedConfirmInput.evaluate(element =>
  316 |         ((element as Element & { ariaDescribedByElements: Element[] | null }).ariaDescribedByElements ?? [])
  317 |           .map(description => ({ id: description.id, text: description.textContent })));
  318 |       expect(descriptions).toContainEqual({ id: 'fc-destructive-dialog-description',
  319 |         text: 'Erasure destroys protected party data and starts irreversible verification.' });
  320 |     }
  321 |     await expect(typedConfirmInput).toHaveAccessibleDescription(/irreversible verification/);
  322 |     {
  323 |       const originalWarning = await warning.textContent();
  324 |       const updatedWarning = 'Updated erasure warning: irreversible verification still applies.';
  325 |       await warning.evaluate((element, text) => { element.firstChild!.nodeValue = text; }, updatedWarning);
  326 |       await expect(typedConfirmInput).toHaveAccessibleDescription(updatedWarning);
  327 |       await warning.evaluate((element, text) => { element.textContent = text; }, originalWarning);
  328 |       await expect(typedConfirmInput).toHaveAccessibleDescription(/irreversible verification/);
  329 |     }
  330 |     await expect(eraseDialogContent.getByRole('button', { name: 'Erase' })).toBeDisabled();
  331 |     for (const mismatch of ['', ' ', 'Grace hopper', 'Grace Hopper ']) {
  332 |       await typedConfirmInput.fill(mismatch);
  333 |       await expect(eraseDialogContent.getByRole('button', { name: 'Erase' })).toBeDisabled();
  334 |     }
  335 |     await expect.poll(async () => (await latestErasureRequest(request))?.partyId ?? null).toBe(null);
  336 |     await eraseDialogContent.getByRole('button', { name: 'Cancel' }).click();
  337 |     await expect(eraseDialog).toHaveCount(0);
  338 |     await expect(portalAction(detail, 'Request erasure')).toBeFocused();
  339 |     await expect(page.getByText(/^Grace hopper$/)).toHaveCount(0);
  340 |     await expect.poll(async () => (await latestErasureRequest(request))?.partyId ?? null).toBe(null);
  341 | 
  342 |     await portalAction(detail, 'Request erasure').click();
  343 |     await expect(eraseDialog).toBeVisible();
  344 |     await page.keyboard.press('Escape');
  345 |     await expect(eraseDialog).toHaveCount(0);
  346 |     await expect(portalAction(detail, 'Request erasure')).toBeFocused();
  347 |     await expect.poll(async () => (await latestErasureRequest(request))?.partyId ?? null).toBe(null);
  348 | 
  349 |     await portalAction(detail, 'Request erasure').click();
  350 |     const reopenedEraseDialog = page.getByRole('dialog', { name: 'Erase party' });
  351 |     await expect(reopenedEraseDialog).toBeVisible();
  352 |     await eraseDialogContent.getByRole('textbox', { name: 'Type the selected party display name', exact: true }).fill('Grace Hopper');
  353 |     await expect(eraseDialogContent.getByRole('status').filter({ hasText: 'Erase action enabled.' })).toBeVisible();
  354 |     await expect(eraseDialogContent.getByRole('button', { name: 'Erase' })).toBeEnabled();
  355 |     const overflow = await page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth);
  356 |     expect(overflow).toBe(false);
  357 |     await eraseDialogContent.getByRole('button', { name: 'Erase' }).click();
  358 |     await expect(detail.getByRole('status').filter({ hasText: 'Saved - updating...' })).toBeVisible();
  359 |     await expect.poll(async () => (await latestErasureRequest(request))?.partyId).toBe('grace-hopper');
  360 |     const erasureRequest = await latestErasureRequest(request);
  361 |     expect(JSON.stringify(erasureRequest)).not.toContain('Grace Hopper');
  362 |     expect(page.url()).not.toContain('Grace%20Hopper');
  363 |     expect(page.url()).not.toContain('Grace+Hopper');
  364 |     expect(nativeDialogs).toEqual([]);
  365 |     expect(browserVisibleDataRequests).toEqual([]);
  366 |   });
  367 | 
  368 |   test('direct GDPR route for a missing party renders bounded state with no mutation controls', async ({ page, request }) => {
  369 |     await page.goto(`${ADMIN_ROUTE}/missing-party/gdpr`);
  370 | 
  371 |     const detail = page.getByLabel('Party detail');
  372 |     await expect(detail.getByRole('status').filter({ hasText: 'The selected party is unavailable' })).toBeVisible();
  373 |     await expect(detail.getByRole('heading', { name: 'GDPR operations', exact: true })).toHaveCount(0);
  374 |     await expectNoGdprMutationControls(detail);
  375 |     await expect.poll(async () => (await latestDetailRequest(request))?.partyId).toBe('missing-party');
  376 |     await expect(detail.getByText('Ada Lovelace')).toHaveCount(0);
  377 |   });
  378 | 
  379 |   test('direct GDPR route for an erased party keeps export and records available without PII', async ({ page, request, context }, testInfo) => {
  380 |     const nativeDialogs: string[] = [];
  381 |     const browserVisibleDataRequests: string[] = [];
  382 |     page.on('dialog', async dialog => {
  383 |       nativeDialogs.push(dialog.type());
  384 |       await dialog.dismiss();
  385 |     });
  386 |     context.on('request', routeRequest => {
  387 |       if (isBrowserVisiblePartiesDataRequest(routeRequest.url())) {
  388 |         browserVisibleDataRequests.push(routeRequest.url());
  389 |       }
  390 |     });
  391 | 
  392 |     await qualifyFrontComposerAssets(page, testInfo);
  393 |     await page.goto(`${ADMIN_ROUTE}/erased-route/gdpr`);
  394 | 
  395 |     const detail = page.getByLabel('Party detail');
  396 |     await expect(detail.locator('h3[data-primary-destination="gdpr"]')).toBeFocused();
  397 |     await expect(detail.getByRole('status').filter({ hasText: 'The selected party is unavailable' })).toBeVisible();
  398 |     await expect(detail.getByText('Erased Route Secret')).toHaveCount(0);
  399 |     await expect(detail.getByText('erased-route@example.test')).toHaveCount(0);
  400 |     await expect(detail.getByText('ERASED-SECRET-ID')).toHaveCount(0);
  401 |     await expect(portalAction(detail, 'Request erasure')).toBeDisabled();
  402 |     await expect(detail.getByRole('button', { name: 'Restrict processing' })).toBeDisabled();
  403 | 
```