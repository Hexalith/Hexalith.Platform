# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: consumer-portal-routes.spec.ts >> Consumer portal route shells >> bound Consumer navigation cancels an active shared download without late feedback or browser resources
- Location: specs/consumer-portal-routes.spec.ts:314:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 10000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: /me/privacy#fc-main-content
  - link "Skip to navigation" [ref=e4] [cursor=pointer]:
    - /url: /me/privacy#fc-nav
  - generic [ref=e6]:
    - banner [ref=e7]:
      - generic [ref=e8]:
        - generic [ref=e9]:
          - button "Toggle navigation" [ref=e12] [cursor=pointer]
          - generic [ref=e16]: Hexalith FrontComposer
        - generic [ref=e17]:
          - 'button "Change theme: Light" [ref=e19] [cursor=pointer]':
            - generic [ref=e20]:
              - generic:
                - generic [ref=e21]: "Change theme: Light"
                - generic [aria-hidden] [ref=e22]: Light
          - button "Open command palette" [ref=e26] [cursor=pointer]
          - button "Open settings" [ref=e30] [cursor=pointer]
          - button "CE" [ref=e35] [cursor=pointer]
    - navigation "Primary navigation" [ref=e38]:
      - generic [ref=e39]:
        - button "Parties" [ref=e40] [cursor=pointer]
        - button "More Parties pages" [ref=e46] [cursor=pointer]
    - generic [ref=e53]:
      - status [ref=e54]: Density set to Compact.
      - main "Main content" [ref=e55]:
        - status [ref=e56]
        - status [ref=e57]
        - region [ref=e59]:
          - generic [ref=e60]:
            - paragraph [ref=e61]:
              - generic: Consumer area
            - heading "Data privacy" [level=1] [ref=e63]
            - paragraph [ref=e64]: You will be able to request a copy of your data and start privacy requests from this protected area.
            - status [ref=e65]: Your JSON export is ready. Only status information is available for this profile.
          - generic [ref=e66]:
            - generic:
              - generic [ref=e67]:
                - heading [level=2] [ref=e68]:
                  - button "Export my data" [expanded] [ref=e69] [cursor=pointer]
                - region "Export my data" [ref=e72]:
                  - generic [ref=e74]:
                    - paragraph [ref=e76]: Machine-readable JSON
                    - paragraph [ref=e77]: Prepare a JSON package for the data connected to your signed-in account.
                    - generic [ref=e78]:
                      - button "Export my data" [ref=e79] [cursor=pointer]
                      - button "Download JSON" [ref=e81] [cursor=pointer]
              - generic [ref=e83]:
                - heading [level=2] [ref=e84]:
                  - button "What we process about you" [expanded] [ref=e85] [cursor=pointer]
                - region "What we process about you" [ref=e88]:
                  - generic [ref=e90]:
                    - paragraph [ref=e91]: Review recent processing activity for your signed-in account. This summary shows bounded audit metadata, not raw payloads or account details.
                    - paragraph [ref=e92]: Shows category, outcome, time, and a safe summary only.
                    - status [ref=e93]: Processing summary is current.
                    - list [ref=e94]:
                      - listitem [ref=e95]:
                        - generic [ref=e96]:
                          - generic [ref=e97]: Data read
                          - generic [ref=e98]: Completed
                        - paragraph [ref=e99]: Bounded GDPR operation record
                        - paragraph [ref=e100]: Recorded 6/10/2026 12:00 PM
                    - paragraph [ref=e101]: This page is a privacy summary. Consent changes are managed on the consent page.
                    - link "Manage all consent" [ref=e102] [cursor=pointer]:
                      - /url: /me/consent
              - generic [ref=e103]:
                - heading [level=2] [ref=e104]:
                  - button "Delete my data" [expanded] [ref=e105] [cursor=pointer]
                - region "Delete my data" [ref=e108]:
                  - generic [ref=e110]:
                    - paragraph [ref=e111]: You have the right to erasure, also called the right to be forgotten. You can cancel until deletion begins. Once it's done, it's permanent - we can't undo it.
                    - paragraph [ref=e112]: No deletion request is active.
                    - button "Delete my data" [ref=e114] [cursor=pointer]
    - generic [ref=e116]: Hexalith FrontComposer © 2026
```

# Test source

```ts
  1  | import { expect, type Page } from '@playwright/test';
  2  | import { portalAction } from './portal-actions.js';
  3  | 
  4  | /** Holds the browser stream-read seam while real page disposal cancels its registered service. */
  5  | export async function expectConsumerNavigationCancelsDownload(page: Page): Promise<void> {
  6  |   const downloads: string[] = [];
  7  |   const errors: string[] = [];
  8  |   page.on('download', download => downloads.push(download.suggestedFilename()));
  9  |   page.on('pageerror', error => errors.push(error.message));
  10 |   await page.goto('/me/privacy');
  11 |   await expect(page.getByRole('heading', { name: 'Data privacy', exact: true })).toBeFocused();
  12 |   await portalAction(page, 'Export my data').click();
  13 |   await expect(page.getByRole('button', { name: 'Download JSON' })).toBeVisible();
  14 |   await page.evaluate(() => {
  15 |     const probe = { entered: false, finished: false, pending: 0, clicks: 0, urls: 0,
  16 |       operationId: '', cancelledId: '', deletes: 0, release: () => {}, restore: () => {} };
  17 |     (window as unknown as { __consumerDownloadProbe: typeof probe }).__consumerDownloadProbe = probe;
  18 |     const read = Response.prototype.arrayBuffer;
  19 |     const set = Map.prototype.set;
  20 |     const remove = Map.prototype.delete;
  21 |     const click = HTMLAnchorElement.prototype.click;
  22 |     const create = URL.createObjectURL;
  23 |     // DotNetStreamReference reads a Response over its real browser stream. Holding
  24 |     // this native read leaves both the producer module and the .NET service intact.
  25 |     Response.prototype.arrayBuffer = async function () {
  26 |       const bytes = await read.call(this);
  27 |       if (probe.pending === 1 && !probe.entered) {
  28 |         probe.entered = true;
  29 |         await new Promise<void>(resolve => { probe.release = resolve; });
  30 |       }
  31 |       return bytes;
  32 |     };
  33 |     // Observe only the producer's operation entries; never replace its module/functions.
  34 |     Map.prototype.set = function (key: unknown, value: unknown) {
  35 |       if (typeof key === 'string' && /^[a-f0-9]{32}$/.test(key)
  36 |           && (value as { cancelled?: unknown } | null)?.cancelled === false) {
  37 |         probe.operationId = key;
  38 |         probe.pending = 1;
  39 |       }
  40 |       return set.call(this, key, value);
  41 |     };
  42 |     Map.prototype.delete = function (key: unknown) {
  43 |       if (probe.operationId && key === probe.operationId) {
  44 |         const operation = this.get(key) as { cancelled?: boolean } | undefined;
  45 |         if (operation?.cancelled) probe.cancelledId = key as string;
  46 |         probe.pending = 0;
  47 |         probe.deletes++;
  48 |         if (probe.deletes === 2) probe.finished = true;
  49 |       }
  50 |       return remove.call(this, key);
  51 |     };
  52 |     HTMLAnchorElement.prototype.click = function () { probe.clicks++; click.call(this); };
  53 |     URL.createObjectURL = blob => { probe.urls++; return create(blob); };
  54 |     probe.restore = () => {
  55 |       Response.prototype.arrayBuffer = read;
  56 |       Map.prototype.set = set;
  57 |       Map.prototype.delete = remove;
  58 |       HTMLAnchorElement.prototype.click = click;
  59 |       URL.createObjectURL = create;
  60 |     };
  61 |   });
  62 |   const probe = () => page.evaluate(() => {
  63 |     const value = (window as unknown as { __consumerDownloadProbe: {
  64 |       entered: boolean; finished: boolean; pending: number; clicks: number; urls: number;
  65 |       operationId: string; cancelledId: string; deletes: number;
  66 |     } }).__consumerDownloadProbe;
  67 |     return { entered: value.entered, finished: value.finished, pending: value.pending,
  68 |       clicks: value.clicks, urls: value.urls, operationId: value.operationId,
  69 |       cancelledId: value.cancelledId, deletes: value.deletes };
  70 |   });
  71 |   try {
  72 |     await page.getByRole('button', { name: 'Download JSON' }).click();
> 73 |     await expect.poll(async () => (await probe()).entered).toBe(true);
     |                                                            ^ Error: expect(received).toBe(expected) // Object.is equality
  74 |     const active = await probe();
  75 |     expect(active.pending).toBe(1);
  76 |     expect(active.operationId).toMatch(/^[a-f0-9]{32}$/);
  77 |     await page.getByRole('link', { name: 'Manage all consent' }).click();
  78 |     await expect(page.getByRole('heading', { name: 'Consent', exact: true })).toBeVisible();
  79 |     await expect.poll(async () => (await probe()).cancelledId).toBe(active.operationId);
  80 |     expect(await probe()).toMatchObject({ pending: 0, finished: false, deletes: 1 });
  81 |     await page.evaluate(() => (window as unknown as { __consumerDownloadProbe: { release: () => void } }).__consumerDownloadProbe.release());
  82 |     await expect.poll(async () => (await probe()).finished).toBe(true);
  83 |     expect(await probe()).toMatchObject({ entered: true, pending: 0, clicks: 0, urls: 0, deletes: 2 });
  84 |     await expect(page.locator('a[download]')).toHaveCount(0);
  85 |     await expect(page.getByRole('alert')).toHaveCount(0);
  86 |     expect(downloads).toEqual([]);
  87 |     expect(errors).toEqual([]);
  88 |   } finally {
  89 |     await page.evaluate(() => {
  90 |       const probe = (window as unknown as { __consumerDownloadProbe: { release: () => void; restore: () => void } }).__consumerDownloadProbe;
  91 |       probe.release();
  92 |       probe.restore();
  93 |     });
  94 |   }
  95 | }
  96 | 
```