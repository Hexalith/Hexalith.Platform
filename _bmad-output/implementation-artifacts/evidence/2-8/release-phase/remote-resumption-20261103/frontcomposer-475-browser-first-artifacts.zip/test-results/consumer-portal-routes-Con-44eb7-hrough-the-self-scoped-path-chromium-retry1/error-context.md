# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: consumer-portal-routes.spec.ts >> Consumer portal route shells >> bound Consumer exports own data through the self-scoped path
- Location: specs/consumer-portal-routes.spec.ts:257:3

# Error details

```
TimeoutError: page.waitForEvent: Timeout 15000ms exceeded while waiting for event "download"
=========================== logs ===========================
waiting for event "download"
============================================================
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: /me/privacy#fc-main-content
  - link "Skip to navigation" [ref=e4] [cursor=pointer]:
    - /url: /me/privacy#fc-nav
  - generic [ref=e6]:
    - banner [ref=e7]:
      - generic [ref=e8]:
        - generic [ref=e9]:
          - button "Toggle navigation" [ref=e12] [cursor=pointer]
          - generic [ref=e16]: Hexalith FrontComposer
        - generic [ref=e17]:
          - 'button "Change theme: Light" [ref=e19] [cursor=pointer]':
            - generic [ref=e20]:
              - generic:
                - generic [ref=e21]: "Change theme: Light"
                - generic [aria-hidden] [ref=e22]: Light
          - button "Open command palette" [ref=e26] [cursor=pointer]
          - button "Open settings" [ref=e30] [cursor=pointer]
          - button "CE" [ref=e35] [cursor=pointer]
    - navigation "Primary navigation" [ref=e38]:
      - generic [ref=e39]:
        - button "Parties" [ref=e40] [cursor=pointer]
        - button "More Parties pages" [ref=e46] [cursor=pointer]
    - generic [ref=e53]:
      - status [ref=e54]: Density set to Compact.
      - main "Main content" [ref=e55]:
        - status [ref=e56]
        - status [ref=e57]
        - region [ref=e59]:
          - generic [ref=e60]:
            - paragraph [ref=e61]:
              - generic: Consumer area
            - heading "Data privacy" [level=1] [ref=e63]
            - paragraph [ref=e64]: You will be able to request a copy of your data and start privacy requests from this protected area.
          - generic [ref=e65]:
            - generic:
              - generic [ref=e66]:
                - heading [level=2] [ref=e67]:
                  - button "Export my data" [expanded] [ref=e68] [cursor=pointer]
                - region "Export my data" [ref=e71]:
                  - generic [ref=e73]:
                    - paragraph [ref=e75]: Machine-readable JSON
                    - paragraph [ref=e76]: Prepare a JSON package for the data connected to your signed-in account.
                    - alert [ref=e77]:
                      - heading "Your data is safe - try again." [level=3] [ref=e79]
                      - paragraph [ref=e80]: Wait a short time, then retry the export.
                    - generic [ref=e81]:
                      - button "Export my data" [ref=e82] [cursor=pointer]
                      - button "Download JSON" [ref=e84] [cursor=pointer]
              - generic [ref=e86]:
                - heading [level=2] [ref=e87]:
                  - button "What we process about you" [expanded] [ref=e88] [cursor=pointer]
                - region "What we process about you" [ref=e91]:
                  - generic [ref=e93]:
                    - paragraph [ref=e94]: Review recent processing activity for your signed-in account. This summary shows bounded audit metadata, not raw payloads or account details.
                    - paragraph [ref=e95]: Shows category, outcome, time, and a safe summary only.
                    - status [ref=e96]: Processing summary is current.
                    - list [ref=e97]:
                      - listitem [ref=e98]:
                        - generic [ref=e99]:
                          - generic [ref=e100]: Data read
                          - generic [ref=e101]: Completed
                        - paragraph [ref=e102]: Bounded GDPR operation record
                        - paragraph [ref=e103]: Recorded 6/10/2026 12:00 PM
                    - paragraph [ref=e104]: This page is a privacy summary. Consent changes are managed on the consent page.
                    - link "Manage all consent" [ref=e105] [cursor=pointer]:
                      - /url: /me/consent
              - generic [ref=e106]:
                - heading [level=2] [ref=e107]:
                  - button "Delete my data" [expanded] [ref=e108] [cursor=pointer]
                - region "Delete my data" [ref=e111]:
                  - generic [ref=e113]:
                    - paragraph [ref=e114]: You have the right to erasure, also called the right to be forgotten. You can cancel until deletion begins. Once it's done, it's permanent - we can't undo it.
                    - paragraph [ref=e115]: No deletion request is active.
                    - button "Delete my data" [ref=e117] [cursor=pointer]
    - generic [ref=e119]: Hexalith FrontComposer © 2026
```

# Test source

```ts
  194 |     await expect(page.getByText('Saved - updating')).toHaveCount(0);
  195 |     expect(browserVisibleDataRequests).toEqual([]);
  196 |   });
  197 | 
  198 |   test('bound Consumer consent surface exposes semantic switches and honest lawful-basis split', async ({ context, page }) => {
  199 |     await enableConsumerFixture(context);
  200 |     const browserVisibleDataRequests = captureBrowserVisiblePartiesDataRequests(page);
  201 | 
  202 |     await page.goto('/me/consent');
  203 | 
  204 |     await expect(page.getByRole('heading', { name: 'Things you control' })).toBeVisible();
  205 |     await expect(page.getByRole('heading', { name: 'Things we keep to run your account' })).toBeVisible();
  206 |     await expect(page.getByRole('switch')).toHaveCount(2);
  207 |     await expectConsentSwitchDescription(page.getByRole('switch', { name: 'Marketing emails' }), [
  208 |       'Messages about offers and campaigns.',
  209 |       'Lawful basis: consent.',
  210 |     ]);
  211 |     await expectConsentSwitchDescription(page.getByRole('switch', { name: 'Product updates' }), [
  212 |       'Messages about new or changed product features.',
  213 |       'Lawful basis: consent.',
  214 |     ]);
  215 |     await expect(page.getByText('Lawful basis: contract.')).toBeVisible();
  216 |     await expect(page.getByText('Lawful basis: legal obligation.')).toBeVisible();
  217 |     await expect(page.getByText('Lawful basis: legitimate interest.')).toBeVisible();
  218 |     await expect(page.getByRole('button', { name: 'Object (Art. 21)' })).toBeDisabled();
  219 |     await expect(page.getByRole('button', { name: 'Withdraw consent' })).toHaveCount(0);
  220 |     await expect(page.getByText('consumer@example.test')).toHaveCount(0);
  221 |     expect(browserVisibleDataRequests).toEqual([]);
  222 |   });
  223 | 
  224 |   test('bound Consumer grants and withdraws consent through the self-scoped command path', async ({ context, page, request }) => {
  225 |     await enableConsumerFixture(context);
  226 |     const browserVisibleDataRequests = captureBrowserVisiblePartiesDataRequests(page);
  227 | 
  228 |     await page.goto('/me/consent');
  229 |     const marketing = page.getByRole('switch', { name: 'Marketing emails' });
  230 |     await expect(marketing).toHaveAttribute('aria-checked', 'false');
  231 | 
  232 |     await marketing.click();
  233 | 
  234 |     await expect.poll(async () => (await latestAddConsentRequest(request))?.partyId ?? null).toBe('party-bound-001');
  235 |     await expect(page.locator('.hx-parties-profile').getByRole('status')).toHaveCount(1);
  236 |     await expect(page.locator('.hx-parties-profile').getByRole('status')).toContainText('Saved');
  237 |     await expect(marketing).toHaveAttribute('aria-checked', 'true');
  238 |     await expect(page.getByText('consumer@example.test')).toHaveCount(0);
  239 | 
  240 |     await marketing.click();
  241 | 
  242 |     await expect.poll(async () => (await latestRevokeConsentRequest(request))?.partyId ?? null).toBe('party-bound-001');
  243 |     await expect(page.locator('.hx-parties-profile').getByRole('status')).toHaveCount(1);
  244 |     await expect(page.locator('.hx-parties-profile').getByRole('status')).toContainText('Saved');
  245 |     await expect(marketing).toHaveAttribute('aria-checked', 'false');
  246 |     await expect.poll(async () => await gdprRequestCounts(request)).toEqual({
  247 |       addConsent: 1,
  248 |       revokeConsent: 1,
  249 |       exportData: 0,
  250 |       erasure: 0,
  251 |       cancelErasure: 0,
  252 |     });
  253 |     expect(new URL(page.url()).pathname).toBe('/me/consent');
  254 |     expect(browserVisibleDataRequests).toEqual([]);
  255 |   });
  256 | 
  257 |   test('bound Consumer exports own data through the self-scoped path', async ({ context, page, request }, testInfo) => {
  258 |     await qualifyFrontComposerAssets(page, testInfo);
  259 |     await enableConsumerFixture(context);
  260 |     const browserVisibleDataRequests = captureBrowserVisiblePartiesDataRequests(page);
  261 | 
  262 |     await page.goto('/me/privacy');
  263 | 
  264 | 
  265 |     await expect(page.getByRole('heading', { name: 'Export my data' })).toBeVisible();
  266 |     await expect(page.getByText('Machine-readable JSON')).toBeVisible();
  267 |     await portalAction(page, 'Export my data').click();
  268 | 
  269 |     await expect(page.getByRole('status').filter({ hasText: 'Your JSON export is ready.' })).toContainText('Your JSON export is ready.');
  270 |     await expect.poll(async () => (await latestExportRequest(request))?.partyId ?? null).toBe('party-bound-001');
  271 |     await expect(page.getByText('Preparing your export - this can take a little while.')).toHaveCount(0);
  272 |     await expect(page.getByText('under one minute')).toHaveCount(0);
  273 |     await expect(page.getByText('party-bound-001')).toHaveCount(0);
  274 |     await page.evaluate(() => {
  275 |       const urls: { url: string; revoked: boolean }[] = [];
  276 |       (window as Window & { __consumerExportUrls?: typeof urls }).__consumerExportUrls = urls;
  277 |       const create = URL.createObjectURL.bind(URL);
  278 |       const revoke = URL.revokeObjectURL.bind(URL);
  279 |       URL.createObjectURL = blob => {
  280 |         const url = create(blob);
  281 |         urls.push({ url, revoked: false });
  282 |         return url;
  283 |       };
  284 |       URL.revokeObjectURL = url => {
  285 |         revoke(url);
  286 |         const transfer = urls.find(item => item.url === url);
  287 |         if (transfer) transfer.revoked = true;
  288 |       };
  289 |       // The registered shared path must execute even though the retained helper is available.
  290 |       window.HexalithPartiesConsumerPortal!.downloadJson = async () => { throw new Error('local fallback executed'); };
  291 |     });
  292 |     const expectedExport = '{"partyId":"party-bound-001","tenantId":"test-tenant","status":"Erased","exportedAt":"2026-06-10T10:00:00Z","exportedBy":"consumer-e2e","correlationId":"corr-export-e2e","party":null,"processingRecords":[]}';
  293 |     for (let attempt = 0; attempt < 2; attempt++) {
> 294 |       const pendingDownload = page.waitForEvent('download');
      |                                    ^ TimeoutError: page.waitForEvent: Timeout 15000ms exceeded while waiting for event "download"
  295 |       await page.getByRole('button', { name: 'Download JSON' }).click();
  296 |       const download = await pendingDownload;
  297 |       expect(await download.failure()).toBeNull();
  298 |       expect(download.suggestedFilename()).toMatch(/^my-data-export-[0-9TZ]+\.json$/);
  299 |       const downloadedPath = await download.path();
  300 |       expect(downloadedPath).not.toBeNull();
  301 |       expect(await readFile(downloadedPath!)).toEqual(Buffer.from(expectedExport, 'utf8'));
  302 |     }
  303 |     await expect.poll(() => page.evaluate(() => {
  304 |       const urls = (window as Window & { __consumerExportUrls?: { revoked: boolean }[] }).__consumerExportUrls ?? [];
  305 |       return { transfers: urls.length, revoked: urls.filter(item => item.revoked).length };
  306 |     })).toEqual({ transfers: 2, revoked: 2 });
  307 |     await expect(page.locator('a[download]')).toHaveCount(0);
  308 |     await expect(page.getByRole('alert')).toHaveCount(0);
  309 |     await expect.poll(async () => (await gdprRequestCounts(request)).exportData).toBe(1);
  310 |     expect(new URL(page.url()).pathname).toBe('/me/privacy');
  311 |     expect(browserVisibleDataRequests).toEqual([]);
  312 |   });
  313 | 
  314 |   test('bound Consumer navigation cancels an active shared download without late feedback or browser resources', async ({ context, page }, testInfo) => {
  315 |     await qualifyFrontComposerAssets(page, testInfo);
  316 |     await enableConsumerFixture(context);
  317 |     await expectConsumerNavigationCancelsDownload(page);
  318 |   });
  319 | 
  320 |   test('bound Consumer sees processing summary through the self-scoped path', async ({ context, page, request }) => {
  321 |     await enableConsumerFixture(context);
  322 |     const browserVisibleDataRequests = captureBrowserVisiblePartiesDataRequests(page);
  323 | 
  324 |     await page.goto('/me/privacy');
  325 | 
  326 |     await expect(page.getByRole('heading', { name: 'What we process about you' })).toBeVisible();
  327 |     await expect(page.getByText('Bounded GDPR operation record')).toBeVisible();
  328 |     await expect(page.getByText('Data read')).toBeVisible();
  329 |     await expect(page.getByText('Completed')).toBeVisible();
  330 |     await expect(page.getByRole('status').filter({ hasText: 'Processing summary is current.' })).toBeVisible();
  331 |     await expect.poll(async () => (await latestProcessingRecordRequest(request))?.partyId ?? null).toBe('party-bound-001');
  332 |     await expect(page.getByText('party-bound-001')).toHaveCount(0);
  333 |     await expect(page.getByText('test-tenant')).toHaveCount(0);
  334 |     await expect(page.getByText('admin-e2e')).toHaveCount(0);
  335 |     await expect(page.getByText('corr-gdpr-e2e')).toHaveCount(0);
  336 | 
  337 |     await page.getByRole('link', { name: 'Manage all consent' }).click();
  338 | 
  339 |     await expect(page.getByRole('heading', { name: 'Consent' })).toBeVisible();
  340 |     expect(new URL(page.url()).pathname).toBe('/me/consent');
  341 |     expect(browserVisibleDataRequests).toEqual([]);
  342 |   });
  343 | 
  344 |   test('bound Consumer sees bounded empty processing state with privacy actions still usable', async ({ context, page, request }) => {
  345 |     await enableConsumerFixture(context);
  346 |     await enableConsumerProcessingStateFixture(context, 'empty');
  347 |     const browserVisibleDataRequests = captureBrowserVisiblePartiesDataRequests(page);
  348 | 
  349 |     await page.goto('/me/privacy');
  350 | 
  351 |     await expect(page.getByRole('heading', { name: 'What we process about you' })).toBeVisible();
  352 |     await expect(page.getByRole('status').filter({ hasText: 'No processing records are available to show right now.' })).toBeVisible();
  353 |     await expect(page.getByText('Bounded GDPR operation record')).toHaveCount(0);
  354 |     await expect(page.getByRole('heading', { name: 'Export my data' })).toBeVisible();
  355 |     await expect(page.getByRole('heading', { name: 'Delete my data' })).toBeVisible();
  356 |     await expect(portalAction(page, 'Export my data')).toBeVisible();
  357 |     await expect(portalAction(page, 'Delete my data')).toBeVisible();
  358 |     await expect(page.getByRole('link', { name: 'Manage all consent' })).toHaveAttribute('href', '/me/consent');
  359 |     await expect.poll(async () => (await latestProcessingRecordRequest(request))?.partyId ?? null).toBe('party-bound-001');
  360 |     await expect(page.getByText('party-bound-001')).toHaveCount(0);
  361 |     await expect(page.getByText('test-tenant')).toHaveCount(0);
  362 |     expect(new URL(page.url()).pathname).toBe('/me/privacy');
  363 |     expect(browserVisibleDataRequests).toEqual([]);
  364 |   });
  365 | 
  366 |   test('bound Consumer sees bounded processing retry guidance after transient load failure', async ({ context, page, request }) => {
  367 |     await enableConsumerFixture(context);
  368 |     await enableConsumerProcessingStateFixture(context, 'transient-failure');
  369 |     const browserVisibleDataRequests = captureBrowserVisiblePartiesDataRequests(page);
  370 | 
  371 |     await page.goto('/me/privacy');
  372 | 
  373 |     await expect(page.getByRole('heading', { name: 'What we process about you' })).toBeVisible();
  374 |     await expect(page.getByRole('alert')).toContainText('Processing summary is unavailable.');
  375 |     await expect(page.getByRole('alert')).toContainText('Try again in a moment. Export and deletion tools remain available where possible.');
  376 |     await expect(page.getByRole('heading', { name: 'Export my data' })).toBeVisible();
  377 |     await expect(page.getByRole('heading', { name: 'Delete my data' })).toBeVisible();
  378 |     await expect(portalAction(page, 'Export my data')).toBeVisible();
  379 |     await expect(portalAction(page, 'Delete my data')).toBeVisible();
  380 |     await expect.poll(async () => (await latestProcessingRecordRequest(request))?.partyId ?? null).toBe('party-bound-001');
  381 |     await expect(page.getByText('Processing records fixture timeout.')).toHaveCount(0);
  382 |     await expect(page.getByText('party-bound-001')).toHaveCount(0);
  383 |     await expect(page.getByText('test-tenant')).toHaveCount(0);
  384 |     await expect(page.getByText('admin-e2e')).toHaveCount(0);
  385 |     await expect(page.getByText('corr-gdpr-e2e')).toHaveCount(0);
  386 |     expect(new URL(page.url()).pathname).toBe('/me/privacy');
  387 |     expect(browserVisibleDataRequests).toEqual([]);
  388 |   });
  389 | 
  390 |   test('bound Consumer requests and cancels erasure through the self-scoped path', async ({ context, page, request }) => {
  391 |     await enableConsumerFixture(context);
  392 |     const browserVisibleDataRequests = captureBrowserVisiblePartiesDataRequests(page);
  393 | 
  394 |     await page.goto('/me/privacy');
```