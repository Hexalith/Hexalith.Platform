"""Bounded diagnostic for the genuine private reader and current topology layer."""
from pathlib import Path
import json,subprocess,os,sys
out=Path('_bmad-output/implementation-artifacts/evidence/2-13').resolve();r=json.loads((out/'published-artifact-identity.json').read_text());job=Path(r['toolRoot']).parents[4];scratch=Path(os.environ['TMPDIR']);env=dict(os.environ,NUGET_PACKAGES=str(job/'packages'),DOTNET_ROLL_FORWARD='LatestPatch');label=sys.argv[1]
props=['-p:UseHexalithProjectReferences=false','-p:HexalithBuildsRoot='+str(Path.cwd()/'references/Hexalith.Builds'),'-p:HexalithBuildsPublishedToolRoot='+r['toolRoot'],'-p:HexalithEventStoreVersion=4.2.0','-p:HexalithTenantsVersion=7.0.7','-p:HexalithMemoriesVersion=3.0.27','-p:HexalithPartiesVersion=3.1.1','-p:HexalithMcpCliVersion=2.0.1']
command=['dotnet','build','tests/Hexalith.Platform.Composition.Tests/Hexalith.Platform.Composition.Tests.csproj','-c','Release','-m:1','--artifacts-path',str(scratch/'build'),*props]
with (out/(label+'-build.log')).open('x') as f:code=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1200).returncode
print('build',code,flush=True)
if code:raise SystemExit(code)
assembly=scratch/'build/bin/Hexalith.Platform.Composition.Tests/release/Hexalith.Platform.Composition.Tests.dll'
command=['dotnet',str(assembly),'-class','Hexalith.Platform.Composition.Tests.PlatformEventStorePackageCatalogReaderTests','-class','Hexalith.Platform.Composition.Tests.PlatformEventStorePackageTestCohortTests','-class','Hexalith.Platform.Composition.Tests.PlatformSdk42EventStorePackageTestCohortTests','-class','Hexalith.Platform.Composition.Tests.PlatformPackageCatalogQualificationTests','-result-xml',str(out/(label+'.xml'))]
with (out/(label+'.log')).open('x') as f:code=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1200).returncode
print('tests',code);raise SystemExit(code)
