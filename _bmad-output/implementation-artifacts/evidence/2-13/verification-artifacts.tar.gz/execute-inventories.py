"""Execute the candidate's explicit inventories using direct xUnit DLL entry; retain exact commands and counts."""
from pathlib import Path
import subprocess,json,sys,xml.etree.ElementTree as ET,datetime
assembly=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=False)
results=[]
for filename in ['tuple-ci-sdk42-current-suites.json','tuple-ci-sdk42-base-suites.json','tuple-ci-extension-suites.json']:
 profile=json.loads((Path('eng')/filename).read_text())
 for number,group in enumerate(profile['groups']):
  label=filename.removesuffix('.json')+'-'+str(number);xml=out/(label+'.xml')
  command=['dotnet',str(assembly),*[arg for selector in group['selectors'] for arg in [group['filter'],selector]],'-result-xml',str(xml)]
  row={'profile':filename,'group':number,'selectors':group['selectors'],'required':group['requiredCount'],'command':command,'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  with (out/(label+'.log')).open('w') as log:
   try:row['exitCode']=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=1200).returncode
   except subprocess.TimeoutExpired:row['exitCode']='timeout'
  if xml.exists():
   doc=ET.parse(xml).getroot().find('assembly');row['counts']=doc.attrib
   row['failures']=[{'name':t.attrib['name'],'message':t.find('failure/message').text if t.find('failure/message') is not None else ''} for t in doc.iter('test') if t.attrib.get('result')=='Fail']
  results.append(row);(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
  print(label,row.get('counts',{}).get('total'),row.get('counts',{}).get('failed'),flush=True)
