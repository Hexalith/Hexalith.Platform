"""Observe only descendants of a newly allocated exact run; never export env or credentials."""
import json,pathlib,subprocess,time,hashlib,re,sys,urllib.parse,datetime,os
out=pathlib.Path(__file__).parent
state_root=pathlib.Path.home()/'.local/share/hexalith-builds/g4-runs'
before=set(json.loads((out/'before-run-files.json').read_text()))
run=None; known={}; seen={}; copied=set(); started=time.monotonic()
def put(name,value):
 with (out/name).open('a') as f:f.write(json.dumps(value,sort_keys=True)+'\n')
def call(args):
 try:return subprocess.run(args,capture_output=True,text=True,timeout=4)
 except (subprocess.TimeoutExpired,FileNotFoundError):return None
def safe(lines):
 result=[]
 for line in lines:
  if re.search(r'-----BEGIN|effectiveEnv|environment\b|authorization\s*[:=]|bearer\s|password|private.?key|client.?secret|signing.?key|[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}',line,re.I):result.append('[sensitive line omitted]')
  else:result.append(line)
 return result
while time.monotonic()-started<1100:
 if run is None:
  for p in state_root.glob('*.json'):
   if p.name in before:continue
   try:d=json.loads(p.read_text());w=pathlib.Path(d['workspace']);plan=json.loads((w/'plan.json').read_text())
   except (OSError,ValueError,KeyError):continue
   if plan.get('platformActiveModule')!='parties':continue
   run=p;put('admission.jsonl',{'runId':d['runId'],'state':str(p),'workspace':str(w),'scope':'read-only descendants of exact AppHost PID/start ticks; no process environment exported'})
   (out/'run-id.txt').write_text(d['runId']);break
 if run:
  try:d=json.loads(run.read_text());pid=d.get('appHostProcessId');w=pathlib.Path(d['workspace'])
  except (OSError,ValueError):time.sleep(1);continue
  if pid:
   processes={}
   for p in pathlib.Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:
     stat=(p/'stat').read_text().rsplit(')',1)[1].split();processes[int(p.name)]=(int(stat[1]),stat[19])
    except (OSError,IndexError,ValueError):continue
   descendants={pid}
   for _ in range(8):descendants|={p for p,(parent,_) in processes.items() if parent in descendants}
   # DCP daemon detaches from AppHost. Admit only via a container mounted under this exact private workspace.
   owned={}
   listing=call(['docker','ps','-q']) if not known else None
   for cid in listing.stdout.split() if listing else []:
    inspect=call(['docker','inspect','--format','{{json .Mounts}}\n{{json .Config.Labels}}',cid])
    try:mounts,labels=[json.loads(x) for x in inspect.stdout.splitlines()]
    except (AttributeError,ValueError):continue
    if not any(pathlib.Path(m.get('Source','/')).is_relative_to(w) for m in mounts):continue
    try:creator=int(labels['com.microsoft.developer.usvc-dev.creatorProcessId'])
    except (KeyError,ValueError):continue
    owned[creator]={'containerId':cid,'containerName':labels.get('com.microsoft.developer.usvc-dev.name'),'uid':labels.get('com.microsoft.developer.usvc-dev.uid'),'binding':'exact run-private mount'}
   descendants|=set(owned)|{p for p,t in known if processes.get(p,(-1,''))[1]==t}
   for child in descendants:
    try:args=[x.decode() for x in (pathlib.Path('/proc')/str(child)/'cmdline').read_bytes().split(b'\0') if x]
    except OSError:continue
    if not args or pathlib.Path(args[0]).name!='dcp' or '--kubeconfig' not in args:continue
    config=pathlib.Path(args[args.index('--kubeconfig')+1]);identity=(child,processes.get(child,(-1,''))[1])
    base=['kubectl','--kubeconfig',str(config),'--request-timeout=2s','--cache-dir',str(out/'private-kube-cache')]
    if identity not in known:
     r=call(base+['config','view','--minify','-o','jsonpath={.clusters[0].cluster.server}'])
     if not r or r.returncode or urllib.parse.urlsplit(r.stdout).hostname not in ['localhost','127.0.0.1','::1']:continue
     known[identity]=config;put('admission.jsonl',{'runId':d['runId'],'appHostPid':pid,'dcpPid':child,'dcpStartTicks':identity[1],'kubeconfigPath':str(config),'loopbackServer':r.stdout,'credentialContentsStored':False,'detachedDaemonAdmission':owned.get(child)})
    r=call(base+['get','executables.usvc-dev.developer.microsoft.com','-o','json'])
    if not r or r.returncode:continue
    try:objects=json.loads(r.stdout).get('items',[])
    except ValueError:continue
    for obj in objects:
     name=obj['metadata']['name'];status=obj.get('status',{});uid=obj['metadata']['uid']
     if not any(name==n or name.startswith(n+'-') for n in ['eventstore','tenants','parties','memories']):continue
     record={'resource':name,'uid':uid,'status':{k:v for k,v in status.items() if k in ['state','processId','pid','exitCode','startupTimestamp','finishTimestamp']}}
     if seen.get(name)!=record:put('status.jsonl',record);seen[name]=record
     files=set()
     for key,value in status.items():
      if isinstance(value,str) and re.search(r'std.?out|std.?err',key,re.I):
       p=pathlib.Path(value)
       if p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(config.parent.resolve()):files.add(p)
     for p in config.parent.iterdir():
      if uid in p.name and re.search(r'_out_|_err_|stdout|stderr|\.log$',p.name) and p.is_file() and not p.is_symlink():files.add(p)
     for p in files:
      try:raw=p.read_bytes()[-131072:]
      except OSError:continue
      sha=hashlib.sha256(raw).hexdigest();key=(str(p),sha)
      if key in copied:continue
      copied.add(key);put('host-logs.jsonl',{'runId':d['runId'],'resource':name,'source':str(p),'rawTailSha256':sha,'lines':safe(raw.decode(errors='replace').splitlines()[-160:])})
  # Run-private files permitted here contain only observed nonsecret catalog/receipt facts.
  if w.exists():
   for p in w.joinpath('platform-components').glob('*-catalog/*'):
    if not p.is_file() or p.suffix!='.json' or p.name not in ['catalog.json','receipt.json'] and not any(x in p.name for x in ['observation','ready','committed','preparation']):continue
    raw=p.read_bytes();key=(str(p),hashlib.sha256(raw).hexdigest())
    if key in copied:continue
    copied.add(key);target=out/'observations'/p.parent.name/p.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
  if (out/'observation-finished').exists():break
 time.sleep(2)
put('observer-end.jsonl',{'elapsedSeconds':round(time.monotonic()-started,2),'runId':run.stem if run else None,'apis':len(known),'logRevisions':len(copied)})
