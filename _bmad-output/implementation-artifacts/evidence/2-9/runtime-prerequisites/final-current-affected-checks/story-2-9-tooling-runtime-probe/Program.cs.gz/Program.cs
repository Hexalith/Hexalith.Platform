using Hexalith.Builds.Tooling.Runtime;
using System.Security.Cryptography;
using System.Reflection;
var ports = CompositionPortAllocator.Allocate(1);
Console.WriteLine(System.Text.Json.JsonSerializer.Serialize(new { assembly = typeof(CompositionRunPlanFactory).Assembly.Location, sha256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(CompositionRunPlanFactory).Assembly.Location))), portCount = ports.ToList().Count, distinctPorts = ports.ToList().Distinct().Count(), ports = ports.ToList() }));
try { _ = CompositionRunPlanFactory.Create(CompositionRunPlanFactory.NewRunId(), "/tmp/probe-only", "/tmp/probe-only", ports, [], [], null, ["/tmp/probe-only/module.json"], null, typeof(CompositionRunPlanFactory).Assembly.Location); Console.WriteLine("factory-empty-modules-nonempty-platform-paths-passed"); }
catch (Exception e) { Console.WriteLine(e.GetType().FullName + ";parameter=" + (e as ArgumentException)?.ParamName); }
