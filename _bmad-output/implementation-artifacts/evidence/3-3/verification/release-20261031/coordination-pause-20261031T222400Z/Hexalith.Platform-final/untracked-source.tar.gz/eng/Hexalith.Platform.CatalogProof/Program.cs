using System.IO.Compression;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using System.Xml.Linq;

using Hexalith.Builds.Tooling.TestEnvironment;
using Hexalith.Builds.Tooling.Runtime;
using Hexalith.Builds.Tooling.Workspace;
using Hexalith.EventStore.Contracts.Routing;

// This reads held public evidence. It never constructs or activates a catalog or grants credentials.
if (args.Length != 4) throw new InvalidDataException("Expected durable run directory, verified delivery manifest, Builds commit and published tool root.");
string directory = Path.GetFullPath(args[0]);
string buildsCommit = args[2];
string toolRoot = Path.GetFullPath(args[3]);
Require(buildsCommit.Length == 40 && buildsCommit.All(char.IsAsciiHexDigit), "Invalid Builds commit.");
Require(Assembly.GetAssembly(typeof(TestEnvironmentContractReader))!.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion.EndsWith("+" + buildsCommit, StringComparison.Ordinal) == true, "The proof reader is outside the selected published Builds revision.");
byte[] Read(string name)
{
    string path = Path.GetFullPath(Path.Combine(directory, name));
    Require(path.StartsWith(directory + Path.DirectorySeparatorChar, StringComparison.Ordinal), "Proof path escaped its bundle.");
    for (FileSystemInfo? current = new FileInfo(path); current is not null && current.FullName != directory; current = current is FileInfo file ? file.Directory : ((DirectoryInfo)current).Parent)
        Require(current.LinkTarget is null, "Linked proof input refused.");
    FileInfo info = new(path);
    Require(info.Exists && info.Length is > 0 and <= 8388608, "Missing or oversized routing proof.");
    return File.ReadAllBytes(path);
}
JsonElement Json(string name) => JsonSerializer.Deserialize<JsonElement>(Read(name));
var descriptorResult = TestEnvironmentContractReader.ReadDescriptor(Path.Combine(directory, "test-environment.json"));
var terminalResult = TestEnvironmentContractReader.ReadResult(Path.Combine(directory, "test-result.json"));
Require(descriptorResult.IsValid && terminalResult.IsValid, "Normal Builds descriptor/result contract refused.");
JsonElement descriptor = Json("test-environment.json"), result = Json("test-result.json");
JsonElement bindings = descriptor.GetProperty("bindings"), run = bindings.GetProperty("run"), environment = bindings.GetProperty("environment");
string runId = run.GetProperty("runId").GetString()!, environmentId = run.GetProperty("environmentId").GetString()!;
Require(environment.GetProperty("mode").GetString() == "package", "Actual descriptor is not package mode.");
Require(environment.GetProperty("catalog").GetProperty("commit").GetString() == buildsCommit
    && environment.GetProperty("catalog").GetProperty("instanceId").GetString() == environmentId + "-catalog", "Descriptor catalog authority/instance disagrees.");
Require(JsonElement.DeepEquals(run, result.GetProperty("bindings").GetProperty("run")) && result.GetProperty("terminal").GetProperty("outcome").GetString() == "passed", "Native owner result failed or belongs to another run.");
var cleanup = result.GetProperty("cleanup");
Require(cleanup.GetProperty("disposition").GetString() == "complete" && cleanup.GetProperty("leftoverResourceIds").GetArrayLength() == 0 && cleanup.GetProperty("failures").GetArrayLength() == 0, "Supported cleanup is incomplete.");
var receipt = Json("routing-catalog/receipt.json");
string root = receipt.GetProperty("rootDigest").GetString()!;
RouteCatalogEnvelope catalog = RouteCatalogCodec.Decode(Read("routing-catalog/catalog.json"), root);
Require(catalog.SchemaVersion == 3 && catalog.Profile == "Development", "Canonical run profile/schema disagrees.");
Require(receipt.GetProperty("instanceId").GetString() == environmentId + "-catalog" && receipt.GetProperty("mode").GetString() == "package", "Reader mode/instance disagrees.");
var mapping = Json("routing-catalog/mapping.json");
var versions = Json("routing-catalog/catalog-versions.json");
Require(mapping.GetProperty("Mode").GetString() == "package" && mapping.GetProperty("ContentHash").GetString() == receipt.GetProperty("sourceMappingHash").GetString()
    && versions.GetProperty("MappingHash").GetString() == receipt.GetProperty("sourceMappingHash").GetString()
    && versions.GetProperty("CatalogCommit").GetString() == buildsCommit, "Held effective mapping/catalog authority disagrees.");
SourceMapping selectedMapping = JsonSerializer.Deserialize<SourceMapping>(Read("routing-catalog/mapping.json"))!;
CatalogVersionSnapshot selectedVersions = JsonSerializer.Deserialize<CatalogVersionSnapshot>(Read("routing-catalog/catalog-versions.json"))!;
Require(selectedMapping.ContentHash == receipt.GetProperty("sourceMappingHash").GetString()
    && selectedVersions.Hash == CatalogVersionSnapshot.ComputeHash(selectedVersions.MappingHash, selectedVersions.CatalogCommit,
        selectedVersions.CatalogFileHash, selectedVersions.PinnedFiles, selectedVersions.Versions, selectedVersions.ProjectVersions), "Held mapping/catalog content hash is invalid.");
var closure = Json("routing-catalog/selected-closure.json");
Require(closure.GetProperty("RunId").GetString() == runId, "Host closure belongs to another run.");
JsonElement[] hosts = closure.GetProperty("hosts").EnumerateArray().ToArray();
string[] expectedHosts = hosts.Select(host => host.GetProperty("ResourceId").GetString()!).Order(StringComparer.Ordinal).ToArray();
Require(expectedHosts.Length >= 5 && expectedHosts.Distinct(StringComparer.Ordinal).Count() == expectedHosts.Length
    && expectedHosts.Contains("eventstore") && expectedHosts.Contains("tenants-api") && expectedHosts.Contains("memories"), "Required cohort host closure is incomplete.");
Require(Directory.EnumerateFiles(Path.Combine(directory, "routing-catalog"), "*.committed.json").Select(Path.GetFileNameWithoutExtension).Select(name => name![..^".committed".Length]).Order(StringComparer.Ordinal).SequenceEqual(expectedHosts), "Readback inventory differs from actual closure.");
foreach (var host in hosts)
{
    string id = host.GetProperty("ResourceId").GetString()!, artifact = host.GetProperty("artifact").GetString()!;
    if (id == "eventstore")
    {
        Require(host.GetProperty("artifactKind").GetString() == "published-seed", "Gateway substituted an owner checkout.");
        string seed = Path.Combine(toolRoot, "g4-host", "projects", "EventStore", "Host.csproj");
        Require(Path.GetFileName(artifact) == "Host.csproj"
            && Hash(File.ReadAllBytes(seed)) == host.GetProperty("artifactSha256").GetString(), "Gateway shim differs from verified published Builds closure.");
    }
    else
    {
        string family = id.StartsWith("tenants", StringComparison.Ordinal) ? "Hexalith.Tenants.Server"
            : id.StartsWith("memories", StringComparison.Ordinal) ? "Hexalith.Memories.Aspire" : "Hexalith.Parties.Aspire";
        string image = id switch { "tenants" => "tenants", "tenants-api" => "tenants-api", "memories" => "memories",
            "memories-domain" => "memories-domain-service", "parties" => "parties", _ => id };
        Require(host.GetProperty("artifactKind").GetString() == "released-image"
            && artifact == "registry.hexalith.com/" + image + ":" + selectedVersions.Versions[family], "Participant substituted another runtime image/version.");
    }
}
long? epoch = null;
foreach (string host in expectedHosts)
{
    var value = JsonSerializer.Deserialize<RouteCatalogGenerationReadback>(Read("routing-catalog/" + host + ".committed.json"))!;
    Require(value.Serving && value.Epoch > 0 && value.Generation == catalog.Generation && value.RootDigest == root && value.Profile == "Development"
        && value.RouteFacetDigest == catalog.RouteFacetDigest && value.IdempotencyFacetDigest == catalog.IdempotencyFacetDigest, "A participant did not serve the common committed catalog.");
    epoch ??= value.Epoch;
    Require(value.Epoch == epoch && value.RequiredHosts.Select(identity => identity.HostId).Order(StringComparer.Ordinal).SequenceEqual(expectedHosts), "Participant epoch/host authority differs.");
    foreach (var identity in value.RequiredHosts)
        Require(hosts.Single(selected => selected.GetProperty("ResourceId").GetString() == identity.HostId).GetProperty("AppId").GetString() == identity.AppId, "Readback target differs from selected host.");
}
var preparation = Json("routing-catalog/preparation.json");
Require(preparation.GetProperty("RunId").GetString() == runId && preparation.GetProperty("routingCatalogMetadataObserved").GetBoolean(), "Native preparation did not observe metadata.");
var metadata = Json("routing-catalog/metadata-http.json");
Require(metadata.GetProperty("method").GetString() == "GET" && metadata.GetProperty("path").GetString() == "/api/v1/routing/catalog" && metadata.GetProperty("status").GetInt32() == 200, "Real public HTTP observation failed.");
var body = metadata.GetProperty("body");
Fields(body, ["schemaVersion", "generation", "rootDigest", "operations"]);
Require(body.GetProperty("schemaVersion").GetInt32() == 3 && body.GetProperty("generation").GetInt64() == catalog.Generation && body.GetProperty("rootDigest").GetString() == root, "Public catalog identity disagrees.");
var publicOperations = catalog.Operations!.Where(operation => operation.Ingress == "public").ToArray();
var observed = body.GetProperty("operations").EnumerateArray().ToArray();
Require(publicOperations.Length > 0 && observed.Select(operation => operation.GetProperty("routeId").GetString()).Order(StringComparer.Ordinal).SequenceEqual(publicOperations.Select(operation => operation.RouteId).Order(StringComparer.Ordinal)), "Public operation inventory exposes internal or missing operations.");
foreach (var operation in publicOperations)
{
    var value = observed.Single(item => item.GetProperty("routeId").GetString() == operation.RouteId);
    var declaration = catalog.Declarations.Single(item => item.RouteId == operation.RouteId);
    Fields(value, ["routeId", "contractVersion", "eligibility", "digest", "requestSchema", "resultSchema", "kind", "domain", "messageType"]);
    Require(value.GetProperty("contractVersion").GetString() == operation.ContractVersion && value.GetProperty("eligibility").GetString() == operation.Eligibility
        && value.GetProperty("digest").GetString() == operation.Digest && value.GetProperty("kind").GetString() == declaration.Kind
        && value.GetProperty("domain").GetString() == declaration.Domain && value.GetProperty("messageType").GetString() == declaration.MessageType
        && JsonElement.DeepEquals(value.GetProperty("requestSchema"), operation.RequestSchema) && JsonElement.DeepEquals(value.GetProperty("resultSchema"), operation.ResultSchema), "Public owner schema/policy changed.");
}
// Archives are downloaded from NuGet and signature-verified by the owning runner before this call.
JsonElement deliveries = JsonSerializer.Deserialize<JsonElement>(File.ReadAllBytes(args[1]));
var artifacts = receipt.GetProperty("loadedArtifacts").EnumerateArray().ToArray();
var assets = Json("routing-catalog/reader-assets.json").GetProperty("libraries");
string[] requiredAssemblies = ["Hexalith.EventStore.Contracts", "Hexalith.Tenants.Contracts", "Hexalith.Tenants.Server", "Hexalith.Memories.EventStore", "Hexalith.Memories.EventStoreExtensions", "Hexalith.Parties.Contracts", "Hexalith.Parties.EventStoreExtensions"];
Require(artifacts.Length == requiredAssemblies.Length, "Reader artifact inventory is incomplete or unexpected.");
foreach (string assembly in requiredAssemblies)
{
    var artifact = artifacts.Single(item => Path.GetFileName(item.GetProperty("path").GetString()) == assembly + ".dll");
    var delivery = deliveries.EnumerateArray().Single(item => item.GetProperty("id").GetString() == assembly);
    string version = delivery.GetProperty("version").GetString()!, archive = delivery.GetProperty("archive").GetString()!;
    string owner = assembly.StartsWith("Hexalith.EventStore.", StringComparison.Ordinal) ? "eventstore"
        : assembly.StartsWith("Hexalith.Tenants.", StringComparison.Ordinal) ? "tenants"
        : assembly.StartsWith("Hexalith.Memories.", StringComparison.Ordinal) ? "memories" : "parties";
    Require(selectedVersions.Versions[assembly] == version
        && CompositionDeclarationOptions.DefaultReleaseCommits[owner + "/" + version] == delivery.GetProperty("commit").GetString(), "Delivered package disagrees with normal Builds release authority.");
    Require(assets.GetProperty(assembly + "/" + version).GetProperty("type").GetString() == "package", "Catalog reader substituted an owner project.");
    using ZipArchive package = ZipFile.OpenRead(archive);
    Require(package.GetEntry(".signature.p7s") is not null && Hash(File.ReadAllBytes(archive)) == delivery.GetProperty("sha256").GetString(), "Delivered archive identity differs.");
    using var nuspecStream = package.Entries.Single(entry => entry.FullName.EndsWith(".nuspec", StringComparison.Ordinal)).Open();
    var nuspec = XDocument.Load(nuspecStream); var repository = nuspec.Descendants().Single(element => element.Name.LocalName == "repository");
    Require(nuspec.Descendants().Single(element => element.Name.LocalName == "id").Value == assembly && nuspec.Descendants().Single(element => element.Name.LocalName == "version").Value == version
        && repository.Attribute("commit")?.Value == delivery.GetProperty("commit").GetString() && repository.Attribute("url")?.Value?.TrimEnd('/') == "https://github.com/Hexalith/" + delivery.GetProperty("repository").GetString(), "Owner package release provenance differs.");
    using var stream = package.Entries.Single(entry => entry.FullName == "lib/net10.0/" + assembly + ".dll").Open();
    using MemoryStream bytes = new(); stream.CopyTo(bytes);
    Require(Hash(bytes.ToArray()) == artifact.GetProperty("sha256").GetString(), "Actually loaded catalog owner differs from delivered package bytes.");
}
Console.WriteLine(JsonSerializer.Serialize(new { status = "passed", kind = "ordinary-package-routing-catalog", candidateAcceptance = false, runId, environmentId, buildsCommit, catalogInstance = environmentId + "-catalog", rootDigest = root, generation = catalog.Generation, epoch, profile = catalog.Profile, hosts = expectedHosts, publicOperationCount = publicOperations.Length, internalOperationCount = catalog.Operations!.Count - publicOperations.Length, readerArtifacts = requiredAssemblies, cleanup = "complete" }));

static string Hash(byte[] bytes) => Convert.ToHexStringLower(SHA256.HashData(bytes));
static void Require(bool condition, string message) { if (!condition) throw new InvalidDataException(message); }
static void Fields(JsonElement value, string[] names) => Require(value.ValueKind == JsonValueKind.Object && value.EnumerateObject().Select(property => property.Name).Order(StringComparer.Ordinal).SequenceEqual(names.Order(StringComparer.Ordinal)), "Public field inventory changed.");
