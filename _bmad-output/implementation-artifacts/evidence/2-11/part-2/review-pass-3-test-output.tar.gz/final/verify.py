from pathlib import Path
import hashlib, json, subprocess, time, xml.etree.ElementTree as ET
repo=Path('/tmp/hexalith-builds-2-11-part-2-20261110')
out=Path(__file__).parent
classes=['NativeTestExecutorTests','LocalRunLifecycleTests','LocalRunCommittedReviewTests','CompositionProcessTests','ExecutingToolIdentityTests','TestResultWriterTests','StartupReadinessTests','StartupCoordinationTests','CiRunLifecycleTests','AttachedSuiteExecutionTests','CompositionNativeProcessDiscoveryTests']
paths=subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines()
def hashes():return {p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
report={'repository':str(repo),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'sourceBefore':hashes(),'classes':[]}
tests=[]
def save(): (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
save()
for cls in classes:
 cmd=['dotnet','exec','test/Hexalith.Builds.Module.Tests/bin/Debug/net10.0/Hexalith.Builds.Module.Tests.dll','-class','Hexalith.Builds.ModuleTool.Tests.'+cls,'-result-xml',str(out/(cls+'.xml'))]
 print('Running '+cls,flush=True)
 started=time.monotonic()
 with (out/(cls+'.log')).open('w') as log:
  result=subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 xml=ET.parse(out/(cls+'.xml')).getroot()
 assembly=xml.find('assembly')
 row={'class':cls,'command':cmd,'exitCode':result.returncode,'seconds':round(time.monotonic()-started,3),'total':int(assembly.get('total')),'failed':int(assembly.get('failed')),'skipped':int(assembly.get('skipped'))}
 tests.extend({'name':t.get('name'),'method':t.get('type')+'.'+t.get('method'),'result':t.get('result')} for t in xml.iter('test'))
 report['classes'].append(row);save()
 print(json.dumps(row),flush=True)
 if result.returncode or row['failed'] or row['skipped']:
  print('FAILED: '+str(out/(cls+'.log')),flush=True)
  raise SystemExit(1)
report['sourceAfter']=hashes()
assert report['sourceBefore']==report['sourceAfter'], 'Source changed during verification'
report['totalPassed']=sum(r['total'] for r in report['classes'])
matrix=json.loads(Path('/home/administrator/projects/hexalith/platform/_bmad-output/implementation-artifacts/evidence/2-11/part-2/matrix-audit.json').read_text())
report['matrixAudit']=[]
for scenario in matrix:
 methods={'Hexalith.Builds.ModuleTool.Tests.'+c['method'] for c in scenario['coverage']}
 passed=[t['name'] for t in tests if t['method'] in methods and t['result']=='Pass']
 assert passed, scenario['scenario']+' has no executed passing coverage'
 report['matrixAudit'].append({'scenario':scenario['scenario'],'passedCases':passed})
report['regressions']={}
for key,method in {'R3-P1':'NativeTestExecutorTests.ReviewDetachedNativeDescendantsAreVerifiedAsync','R3-P1-discovery':'NativeTestExecutorTests.ReviewProtectedProcessesPreserveNativeDiscoveryHonestyAsync','R3-P1-order':'NativeTestExecutorTests.ReviewCausalOutcomePrecedesDescendantStoppingAsync','R3-P2':'LocalRunLifecycleTests.ReviewNativeReplayPreservesFullTerminationObservationTimesAsync','R3-P3':'NativeTestExecutorTests.ReviewNativeAccessKeepsFirstPendingObservation','R3-P4':'LocalRunCommittedReviewTests.RunningSuitePublishesExecutionActivationForListingAsync','R3-P5':'LocalRunLifecycleTests.RecoveryPreservesExecutorAndFreezesObservedInterruptionAsync'}.items():
 passed=[t['name'] for t in tests if t['method']=='Hexalith.Builds.ModuleTool.Tests.'+method and t['result']=='Pass']
 assert passed, key+' regression was not executed'
 report['regressions'][key]=passed
report['postImplementationReviewCoverage']={}
for method in ['NativeTestExecutorTests.ReviewCausalOutcomePrecedesDescendantStoppingAsync','NativeTestExecutorTests.ReviewCancelledNativeScanPreservesKnownDescendantsAsync','NativeTestExecutorTests.NativeStoppingDoesNotRenewAfterOutcomeRecordingAsync','CompositionNativeProcessDiscoveryTests.NativeTaggedChildRemovalPreservesIndependentPeerAsync']:
 passed=[t['name'] for t in tests if t['method']=='Hexalith.Builds.ModuleTool.Tests.'+method and t['result']=='Pass']
 assert passed, method+' was not executed'
 report['postImplementationReviewCoverage'][method]=passed
report['binaryTimestamps']={str(p):{'mtimeNs':p.stat().st_mtime_ns,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [repo/'test/Hexalith.Builds.Module.Tests/bin/Debug/net10.0/Hexalith.Builds.Module.Tests.dll',repo/'src/libraries/Hexalith.Builds.Tooling/bin/Debug/net10.0/Hexalith.Builds.Tooling.dll',repo/'src/libraries/Hexalith.Builds.Module.Cli/bin/Debug/net10.0/Hexalith.Builds.Module.Cli.dll']}
save()
print('VERIFIED '+str(report['totalPassed'])+' passing C# cases; all six matrix rows and all five corrections covered.',flush=True)
