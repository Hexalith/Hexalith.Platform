# Story 2.11 part 2 — lifecycle observation implementation evidence

The implementation is in `/tmp/hexalith-builds-2-11-part-2-20261110`, branch
`feat/2-11-lifecycle-reporting`, as uncommitted changes from Builds revision
`52ea174c70f1afe77b52a2ccf06bb53afa5e962d`. The authoritative specification is
[spec-2-11-report-lifecycle-observations.md](../../../spec-2-11-report-lifecycle-observations.md).
Platform HEAD during verification was `d7c74e8a5d5627a8773fb36652813fe743de3d6f`. The existing Builds
checkout and Platform gitlink were preserved. No remote operations were performed.
[changed-files.json](changed-files.json) records SHA-256 identities of the implementation
files; [verification.json](verification.json) records revisions, actual CLI version,
binary timestamps and unchanged schema hashes.

## Observations implemented

Startup elapsed seconds freeze at the first readiness, failure, timeout or observed
interruption, before diagnostic collection and teardown. First/final results, owner state
and startup summaries reuse the measurement and original request/deadline/override.
If an outcome lock is contended, the runner holds the first observation in memory and
persists it at the first successful publication, preserving existing refusal behavior and
stopping bounds. Recovery timestamps its observed interruption; it cannot recover an
unobserved death instant. Unknown legacy measurements remain unavailable.

The executing identity is `hexalith-module` and its actual CLI informational version
without build metadata. Its content identity is the SHA-256 of exact compact UTF-8 JSON
manifest bytes, without a BOM or final newline. Manifest property order is `schema`,
`algorithm`, `binaries`; values are `hexalith.executing-tool-manifest.v1`, `sha256`, and
an ordinal filename-sorted array of `Hexalith.Builds.Module.Cli.dll` and
`Hexalith.Builds.Tooling.dll`. Each binary entry contains `name`, then `contentIdentity`
(`sha256:` plus the lowercase SHA-256 of the entire binary file). The manifest itself
has the same `sha256:` digest form, and exact bytes remain a classified internal
`executing-tool-<digest>.json` diagnostic. Hash failure refuses fresh provisioning;
cleaners and reconnects retain the original identity. The digest identifies binary content
and supplies no package provenance or qualification. Existing qualification bindings are
preserved, and newly issued qualification fields remain unavailable.

Owner termination distinguishes observed native work, environment work and access.
Unissued items are not applicable, retained environment/access stays pending, and observed
native exit can be terminated independently. Verified exact cleanup advances environment
and access to terminated; incomplete or unverifiable cleanup reports failures, classified
diagnostics and known leftovers. Passing tests alone supply no cleanup or revocation proof.
Attached records retain part 1's stopping/access observations, original expiry, and the live
owner's executor and environment startup measurement. The hosted-workflow helper retains
these fields and original hash-checked diagnostic bytes; it produces no second identity.

## Verification

All 260 tests in the eight required xUnit classes passed with zero skips, errors
or unexecuted cases; Python passed 70 tests. The Debug build passed with zero warnings/errors.
The CLI, Tooling and test binaries are newer than their sources. Both unchanged v1 schemas
and the unchanged contract reader validated emitted descriptors/results throughout these
tests. `git diff --check` passed.

| xUnit class | Passed | Evidence |
| --- | ---: | --- |
| `ExecutingToolIdentityTests` | 4 | [log](ExecutingToolIdentityTests.log), [XML](ExecutingToolIdentityTests.xml) |
| `TestResultWriterTests` | 26 | [log](TestResultWriterTests.log), [XML](TestResultWriterTests.xml) |
| `LocalRunLifecycleTests` | 62 | [log](LocalRunLifecycleTests.log), [XML](LocalRunLifecycleTests.xml) |
| `NativeTestExecutorTests` | 48 | [log](NativeTestExecutorTests.log), [XML](NativeTestExecutorTests.xml) |
| `StartupReadinessTests` | 32 | [log](StartupReadinessTests.log), [XML](StartupReadinessTests.xml) |
| `StartupCoordinationTests` | 14 | [log](StartupCoordinationTests.log), [XML](StartupCoordinationTests.xml) |
| `CiRunLifecycleTests` | 29 | [log](CiRunLifecycleTests.log), [XML](CiRunLifecycleTests.xml) |
| `AttachedSuiteExecutionTests` | 45 | [log](AttachedSuiteExecutionTests.log), [XML](AttachedSuiteExecutionTests.xml) |

The exact commands below ran from the isolated Builds worktree. Each xUnit invocation uses
one filter kind (`-class`). See [build.log](build.log), [python-unittest.log](python-unittest.log)
and [test-results.json](test-results.json).

```bash
dotnet build test/Hexalith.Builds.Module.Tests -c Debug -nodeReuse:false
dotnet test/Hexalith.Builds.Module.Tests/bin/Debug/net10.0/Hexalith.Builds.Module.Tests.dll -class Hexalith.Builds.ModuleTool.Tests.ExecutingToolIdentityTests -verbose -result-xml /tmp/hexalith-2-11-ExecutingToolIdentityTests.xml
dotnet test/Hexalith.Builds.Module.Tests/bin/Debug/net10.0/Hexalith.Builds.Module.Tests.dll -class Hexalith.Builds.ModuleTool.Tests.TestResultWriterTests -verbose -result-xml /tmp/hexalith-2-11-TestResultWriterTests.xml
dotnet test/Hexalith.Builds.Module.Tests/bin/Debug/net10.0/Hexalith.Builds.Module.Tests.dll -class Hexalith.Builds.ModuleTool.Tests.LocalRunLifecycleTests -verbose -result-xml /tmp/hexalith-2-11-LocalRunLifecycleTests.xml
dotnet test/Hexalith.Builds.Module.Tests/bin/Debug/net10.0/Hexalith.Builds.Module.Tests.dll -class Hexalith.Builds.ModuleTool.Tests.NativeTestExecutorTests -verbose -result-xml /tmp/hexalith-2-11-NativeTestExecutorTests.xml
dotnet test/Hexalith.Builds.Module.Tests/bin/Debug/net10.0/Hexalith.Builds.Module.Tests.dll -class Hexalith.Builds.ModuleTool.Tests.StartupReadinessTests -verbose -result-xml /tmp/hexalith-2-11-StartupReadinessTests.xml
dotnet test/Hexalith.Builds.Module.Tests/bin/Debug/net10.0/Hexalith.Builds.Module.Tests.dll -class Hexalith.Builds.ModuleTool.Tests.StartupCoordinationTests -verbose -result-xml /tmp/hexalith-2-11-StartupCoordinationTests.xml
dotnet test/Hexalith.Builds.Module.Tests/bin/Debug/net10.0/Hexalith.Builds.Module.Tests.dll -class Hexalith.Builds.ModuleTool.Tests.CiRunLifecycleTests -verbose -result-xml /tmp/hexalith-2-11-CiRunLifecycleTests.xml
dotnet test/Hexalith.Builds.Module.Tests/bin/Debug/net10.0/Hexalith.Builds.Module.Tests.dll -class Hexalith.Builds.ModuleTool.Tests.AttachedSuiteExecutionTests -verbose -result-xml /tmp/hexalith-2-11-AttachedSuiteExecutionTests.xml
python3 -m unittest discover -s Github/run-module-integration/tests
```

The initial local lifecycle run had three outcome-lock contention failures. Timing persistence
was corrected to preserve the existing HXR037 refusal and original stopping budget; all 62
cases passed on the final rerun. The [initial failed log](LocalRunLifecycleTests.initial-failed.log)
is retained.

The first attached-class attempt had 16 assertion failures because its manually persisted
fixture owner omitted the executor/startup facts already known by the executing session.
The fixture now captures the original executor before allocation and persists the same
startup/deadline observations. The rerun passed all 45 cases. The original
[failed log](AttachedSuiteExecutionTests.initial-failed.log) and
[failed XML](AttachedSuiteExecutionTests.initial-failed.xml) remain available for review.

The final local lifecycle rerun passed 62 cases, including the added
`RecoveryReadsNativeLedgerAfterFirstOutcomeCommitAsync` regression. It simulates a crash
between the first terminal commit and its termination update: recovery restores the
separate native launch/access ledger, preserves the first terminal and verifies ending
access through exact cleanup. Other required class passes and their exact execution times
remain recorded in their XML files.

## Matrix audit

Every covering method below appears as passing in the linked class XML and verbose log.
[matrix-audit.json](matrix-audit.json) lists exact executed case names. The delayed teardown
test snapshots the first published result before a delayed cleanup helper and compares its
frozen duration with the final result, durable owner state and startup summary; its timeout
and cancellation cases both ran. Recovery and CI retry tests preserve the executor under a
cleaner whose identity-capture seam deliberately throws if invoked. Attached fallback tests
also forbid recapturing the reconnecting executor.

| Approved scenario | Executed coverage |
| --- | --- |
| Ready | `StartupReadinessTests.ReadyRunRecordsDeadlineAndDebugProcessIdsAsync` (2 passing cases); `StartupCoordinationTests.DeadlineAtFinalReadyCommitRefusesSuccessAsync` (1 passing cases) |
| Partial | `StartupReadinessTests.StartupObservationExcludesDelayedTeardownAsync` (2 passing cases); `StartupReadinessTests.StartupTaskFailureNamesTheTaskAndPreservesDiagnosticsAsync` (2 passing cases); `StartupReadinessTests.StartupTaskIsStoppedAtTheDeadlineAsync` (2 passing cases); `StartupCoordinationTests.SetupCancellationRecordsOriginalStartupAndUnissuedWorkAsync` (1 passing cases) |
| Recovery | `LocalRunLifecycleTests.RecoveryReadsNativeLedgerAfterFirstOutcomeCommitAsync` (1 passing cases); `LocalRunLifecycleTests.RecoveryPreservesExecutorAndFreezesObservedInterruptionAsync` (2 passing cases); `LocalRunLifecycleTests.LegacySelectedOwnerRecoveryPreservesUnknownFieldsAsync` (4 passing cases); `TestResultWriterTests.LegacyExecutorRemainsUnavailableWithDiagnosticsAsync` (1 passing cases) |
| Retained | `LocalRunLifecycleTests.NativeOutcomeControlsLocalCleanupAsync` (6 passing cases); `NativeTestExecutorTests.PreparedScopeBindsNativeTokenAndDomainHandoffAsync` (1 passing cases); `AttachedSuiteExecutionTests.AttachedFailureRetainsOnlyLocallyAndLeavesOwnerUntouchedAsync` (2 passing cases) |
| Cleanup | `CiRunLifecycleTests.CiTerminationDiscoveryFailureAndRetryPreserveFirstIdentityAsync` (1 passing cases); `LocalRunLifecycleTests.DiscoveryFailureReportsClaimsAndRetryPreservesPeerAsync` (2 passing cases); `LocalRunLifecycleTests.OutcomeLockImmediatelyRefusesCleanupUntilExactRetryAsync` (1 passing cases) |
| Attached | `AttachedSuiteExecutionTests.PassingAttachedSuiteEndsWorkAndAccessAsync` (2 passing cases); `AttachedSuiteExecutionTests.DownStopsAttachedWorkOfVanishedOwnerAsync` (2 passing cases); `AttachedSuiteExecutionTests.AttacherTakesOverWhenOwnerVanishesMidRunAsync` (1 passing cases); `AttachedSuiteExecutionTests.RetryReconnectsLineageAndRefusesEndedOrExpiredAsync` (1 passing cases) |

Binary identity content-change/refusal coverage is in
`ExecutingToolIdentityTests.ChangedBinaryBytesChangeManifestIdentityAsync` (both binaries)
and `HashFailureRefusesBeforeProvisioningAsync`. Artifact retention and identical-retry
coverage is in Python's
`test_published_redacted_diagnostics_survive_cleanup_byte_for_byte_and_retry`, with mismatched
and malformed manifest refusals also executed.

## Verification limits

This is local Debug implementation evidence using process, Docker and AppHost controls.
It is not hosted package-mode qualification, published package provenance, independent tool
acceptance, a Parties caller adoption or Story 2.10/part 3 completion. No policy, v1 schema,
contract reader, qualification reference, catalog/tool pin or hosted dispatch was changed.
Original termination outcomes and attachment holds remain distinct from evolving cleanup.
