// <copyright file="CompositionRunPlan.cs" company="ITANEO">
// Copyright (c) ITANEO (https://www.itaneo.com). All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
// </copyright>

namespace Hexalith.Builds.Tooling.Runtime;

using Hexalith.Builds.Tooling.Workspace;

/// <summary>
/// The metadata-only plan the runner hands to the Builds-owned AppHost for one run.
/// </summary>
/// <remarks>
/// The plan never contains a credential. The per-run signing key travels only through the AppHost
/// child-process environment and the in-memory <see cref="CompositionRunSession"/>.
/// </remarks>
/// <param name="Schema">The plan schema identity.</param>
/// <param name="RunId">The unique run identity carried by every resource.</param>
/// <param name="TenantNamespace">The run-unique tenant used for authorized writes.</param>
/// <param name="ForeignTenantNamespace">A run-unique tenant the run identity is never granted.</param>
/// <param name="ResourceNamespace">The run-unique resource namespace (container and aggregate prefix).</param>
/// <param name="Workspace">The absolute, runner-owned run workspace directory.</param>
/// <param name="DaprHome">The absolute verified Dapr home (CLI in <c>tools/dapr</c>, runtime in <c>.dapr/bin</c>).</param>
/// <param name="ReadinessPath">The absolute path at which the AppHost writes its readiness document.</param>
/// <param name="DaprConfigPath">The rendered per-run Dapr configuration (name resolution) path.</param>
/// <param name="StateStoreComponentPath">The rendered per-run state-store component path.</param>
/// <param name="PubSubComponentPath">The rendered per-run pub/sub component path.</param>
/// <param name="IsolatedResourcesPath">The empty per-run resources directory used by isolated module sidecars.</param>
/// <param name="RedisImage">The digest-pinned Redis image reference (<c>repository:tag@sha256:digest</c>).</param>
/// <param name="Ports">The allocated run-scoped ports.</param>
/// <param name="Modules">The deterministically ordered modules.</param>
/// <param name="UiMarkers">The deterministically ordered FrontComposer marker bindings.</param>
public sealed record CompositionRunPlan(
    string Schema,
    string RunId,
    string TenantNamespace,
    string ForeignTenantNamespace,
    string ResourceNamespace,
    string Workspace,
    string DaprHome,
    string ReadinessPath,
    string DaprConfigPath,
    string StateStoreComponentPath,
    string PubSubComponentPath,
    string IsolatedResourcesPath,
    string RedisImage,
    CompositionRunPorts Ports,
    IReadOnlyList<CompositionRunModule> Modules,
    IReadOnlyList<CompositionRunUiMarker> UiMarkers)
{
    /// <summary>
    /// The supported run-plan schema identity.
    /// </summary>
    public const string SupportedSchema = "hexalith.g4-run-plan.v1";

    /// <summary>Gets the immutable workspace source mapping, when resolved by the command.</summary>
    public SourceMapping? SourceMapping { get; init; }

    /// <summary>Gets the v2 owner declaration paths handed to the Platform model.</summary>
    public IReadOnlyList<string> PlatformDeclarationPaths { get; init; } = [];

    /// <summary>Gets the content hash of the v2 declaration that the command selected.</summary>
    public string? PlatformDeclarationHash { get; init; }

    /// <summary>Gets the immutable authoritative composition closure content identity.</summary>
    public string? CompositionContentIdentity { get; init; }

    /// <summary>Gets the selected v2 module identity.</summary>
    public string? PlatformActiveModule { get; init; }

    /// <summary>Gets the built model from the pinned Platform checkout.</summary>
    public string? PlatformModelAssemblyPath { get; init; }

    /// <summary>Gets the run-scoped Debug McpCli tool built from the mapped checkout for an McpCli source run.</summary>
    public string? McpCliToolPath { get; init; }

    /// <summary>Gets a value indicating whether this is a declaration-driven Platform composition.</summary>
    public bool IsPlatformComposition => PlatformDeclarationPaths.Count > 0;

    /// <summary>Gets the Platform identity used by this composition.</summary>
    public PlatformIdentity? PlatformIdentity => SourceMapping?.PlatformIdentity;

    /// <summary>Gets the mapping content hash used by every launched project.</summary>
    public string? SourceMappingHash => SourceMapping?.ContentHash;

    /// <summary>
    /// Gets the Redis container name, which carries the run identity.
    /// </summary>
    public string RedisContainerName => $"hexalith-g4-{RunId}-redis";

    /// <summary>Gets the absolute startup deadline measured from the start request.</summary>
    public DateTimeOffset? StartupDeadlineUtc { get; init; }

    /// <summary>Gets the effective deadline recorded for this run.</summary>
    public CompositionEffectiveDeadline? EffectiveDeadline { get; init; }

    /// <summary>Gets a value indicating whether projects launch in Debug and report process ids.</summary>
    public bool DebugAttach { get; init; }

    /// <summary>Gets the per-start verification tasks that must succeed before the run is ready.</summary>
    public IReadOnlyList<CompositionStartupTask> StartupTasks { get; init; } = [];

    /// <summary>Gets the immutable selected module-owned test binding, when present.</summary>
    public ModuleTestSelection? SelectedTest { get; init; }

    /// <summary>Gets the immutable compatible batch selections.</summary>
    public IReadOnlyList<ModuleTestSelection> SelectedTests { get; init; } = [];

    /// <summary>Gets the actual execution activation, persisted before the child starts.</summary>
    public ModuleTestExecutionTiming? ExecutionTiming { get; init; }

    /// <summary>Gets the runner-issued environment identity.</summary>
    public string EnvironmentId { get; init; } = Guid.NewGuid().ToString("N");

    /// <summary>Gets the runner-issued attempt identity, distinct from the run.</summary>
    public string AttemptId { get; init; } = Guid.NewGuid().ToString("N");

    /// <summary>Gets the runner-owned claim state directory for child allocation.</summary>
    public string? ResourceClaimStateDirectory { get; init; }

    /// <summary>Gets a value indicating whether local selected-test failures retain surviving resources until explicit down.</summary>
    public bool RetainOnFailure { get; init; }
}
