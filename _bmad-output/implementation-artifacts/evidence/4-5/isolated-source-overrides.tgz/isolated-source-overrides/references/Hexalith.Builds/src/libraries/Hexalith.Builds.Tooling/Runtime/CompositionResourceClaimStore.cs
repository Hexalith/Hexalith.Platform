// <copyright file="CompositionResourceClaimStore.cs" company="ITANEO">
// Copyright (c) ITANEO (https://www.itaneo.com). All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
// </copyright>

namespace Hexalith.Builds.Tooling.Runtime;

using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

/// <summary>Atomically claims actual exclusive resources across runner processes; composition identity is never a lock.</summary>
/// <param name="stateDirectory">The runner's state directory.</param>
public sealed class CompositionResourceClaimStore(string stateDirectory)
{
    private readonly string _directory = Path.Combine(Path.GetFullPath(stateDirectory), "claims");

    /// <summary>Claims the complete exclusive set, rolling back only this acquisition on conflict.</summary>
    /// <param name="runId">The owning run.</param>
    /// <param name="resourceIds">The actual exclusive identities.</param>
    /// <exception cref="CompositionResourceClaimConflictException">Another managed run owns a resource.</exception>
    public void Acquire(string runId, IEnumerable<string> resourceIds)
    {
        ArgumentNullException.ThrowIfNull(resourceIds);
        ArgumentOutOfRangeException.ThrowIfEqual(CompositionRunPlanFactory.IsRunId(runId), false);
        CompositionWorkspace.CreatePrivateDirectory(_directory);
        using FileStream transaction = OpenTransaction();
        List<string> acquired = [];
        try
        {
            foreach (string resourceId in resourceIds.Distinct(StringComparer.Ordinal).Order(StringComparer.Ordinal))
            {
                ArgumentException.ThrowIfNullOrWhiteSpace(resourceId);
                string path = PathFor(resourceId);
                try
                {
                    using FileStream stream = new(path, FileMode.CreateNew, FileAccess.Write, FileShare.None);
                    acquired.Add(path);
                    JsonSerializer.Serialize(stream, new CompositionResourceClaim(resourceId, runId));
                    stream.Flush(flushToDisk: true);
                    if (!OperatingSystem.IsWindows())
                    {
                        File.SetUnixFileMode(path, UnixFileMode.UserRead | UnixFileMode.UserWrite);
                    }
                }
                catch (IOException) when (File.Exists(path) && !acquired.Contains(path, StringComparer.Ordinal))
                {
                    throw new CompositionResourceClaimConflictException(resourceId, ReadOwner(path) ?? "unknown");
                }
            }
        }
        catch
        {
            foreach (string path in acquired)
            {
                File.Delete(path);
            }

            throw;
        }
    }

    /// <summary>Releases only claims whose durable owner matches a verified cleaned run.</summary>
    /// <param name="runId">The cleaned owning run.</param>
    public void ReleaseOwned(string runId)
    {
        if (!Directory.Exists(_directory))
        {
            return;
        }

        using FileStream transaction = OpenTransaction();
        foreach (string path in Directory.EnumerateFiles(_directory, "*.json").Where(path => ReadOwner(path) == runId))
        {
            File.Delete(path);
        }
    }

    private static string? ReadOwner(string path)
    {
        try
        {
            using FileStream stream = File.OpenRead(path);
            return JsonSerializer.Deserialize<CompositionResourceClaim>(stream)?.OwnerRunId;
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or JsonException)
        {
            return null;
        }
    }

    private FileStream OpenTransaction()
    {
        long started = System.Diagnostics.Stopwatch.GetTimestamp();
        while (true)
        {
            try
            {
                return new FileStream(Path.Combine(_directory, "transaction.lock"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
            }
            catch (IOException) when (System.Diagnostics.Stopwatch.GetElapsedTime(started) < TimeSpan.FromSeconds(2))
            {
                Thread.Sleep(5);
            }
        }
    }

    private string PathFor(string resourceId) => Path.Combine(_directory, Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(resourceId))) + ".json");
}
