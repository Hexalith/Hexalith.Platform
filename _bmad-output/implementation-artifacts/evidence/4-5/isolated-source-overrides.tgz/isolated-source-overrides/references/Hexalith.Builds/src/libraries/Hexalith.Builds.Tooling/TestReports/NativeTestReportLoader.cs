// <copyright file="NativeTestReportLoader.cs" company="ITANEO">
// Copyright (c) ITANEO (https://www.itaneo.com). All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
// </copyright>

namespace Hexalith.Builds.Tooling.TestReports;

using System.Globalization;
using System.Security.Cryptography;
using System.Xml;
using System.Xml.Linq;

using Hexalith.Builds.Tooling.Diagnostics;

/// <summary>
/// Loads native TRX reports emitted by VSTest and Microsoft Testing Platform without replacing their outcomes.
/// </summary>
public static class NativeTestReportLoader
{
    /// <summary>
    /// Loads a native test report and rejects missing, invalid, zero-match, all-skipped, and failed results.
    /// </summary>
    /// <param name="reportPath">The report path.</param>
    /// <param name="cancellationToken">The cancellation token.</param>
    /// <returns>A normalized report or a stable non-passing diagnostic.</returns>
    public static async Task<NativeTestReportLoadResult> LoadAsync(string reportPath, CancellationToken cancellationToken)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(reportPath);

        string fullPath;
        try
        {
            fullPath = Path.GetFullPath(reportPath);
        }
        catch (ArgumentException)
        {
            return Failed("HXT001", "report");
        }
        catch (NotSupportedException)
        {
            return Failed("HXT001", "report");
        }

        if (!File.Exists(fullPath))
        {
            return Failed("HXT001", "report");
        }

        byte[] bytes;
        try
        {
            bytes = await File.ReadAllBytesAsync(fullPath, cancellationToken).ConfigureAwait(false);
        }
        catch (IOException)
        {
            return Failed("HXT001", "report");
        }
        catch (UnauthorizedAccessException)
        {
            return Failed("HXT001", "report");
        }

        return LoadBytes(fullPath, bytes);
    }

    /// <summary>Evaluates already inspected report bytes without reopening a mutable path.</summary>
    /// <param name="fullPath">The report identity used for metadata.</param>
    /// <param name="bytes">The inspected XML bytes.</param>
    /// <returns>The existing native report result.</returns>
    internal static NativeTestReportLoadResult LoadBytes(string fullPath, byte[] bytes)
    {
        XDocument document;
        try
        {
            using MemoryStream stream = new(bytes, writable: false);
            document = XDocument.Load(stream, LoadOptions.None);
        }
        catch (XmlException)
        {
            return Failed("HXT002", "report");
        }

        if (document.Root is null || !string.Equals(document.Root.Name.LocalName, "TestRun", StringComparison.Ordinal))
        {
            return Failed("HXT002", "report");
        }

        XElement[] resultSummaries = [.. document.Root.Elements().Where(element =>
            string.Equals(element.Name.LocalName, "ResultSummary", StringComparison.Ordinal)),
        ];
        if (resultSummaries.Length != 1)
        {
            return Failed("HXT002", "resultSummary");
        }

        XElement resultSummary = resultSummaries[0];

        // VSTest/MTP report a run-level outcome distinct from per-test counters (e.g. a
        // test-host crash or aborted run can leave clean counters). Only a run explicitly
        // reported as "Completed" — or a report that omits the attribute entirely — can
        // represent a pass; every other declared outcome fails closed.
        string? outcome = resultSummary.Attribute("outcome")?.Value;
        if (outcome is not null && !string.Equals(outcome, "Completed", StringComparison.Ordinal))
        {
            return Failed("HXT006", "outcome");
        }

        XElement[] counterElements = [.. resultSummary.Elements().Where(element =>
            string.Equals(element.Name.LocalName, "Counters", StringComparison.Ordinal)),
        ];
        XElement? counters = counterElements.Length == 1 ? counterElements[0] : null;
        return counters is null || !TryReadCounters(counters, out int total, out int passed, out int failed, out int skipped)
            ? Failed("HXT002", "counters")
            : CreateResult(fullPath, bytes, total, passed, failed, skipped);
    }

    private static NativeTestReportLoadResult CreateResult(
        string fullPath,
        byte[] bytes,
        int total,
        int passed,
        int failed,
        int skipped) =>
        (total, passed, failed, skipped) switch
        {
            (0, _, _, _) => Failed("HXT003", "total"),
            (_, _, > 0, _) => Failed("HXT005", "failed"),
            (_, 0, _, _) => Failed("HXT004", "skipped"),
            _ when (long)passed + skipped != total => Failed("HXT002", "counters"),
            _ => new NativeTestReportLoadResult(
                new NativeTestReport(
                    Path.GetFileName(fullPath),
                    Convert.ToHexString(SHA256.HashData(bytes)),
                    total,
                    passed,
                    failed,
                    skipped),
                null),
        };

    private static NativeTestReportLoadResult Failed(string ruleId, string field) => new(
        null,
        new ToolDiagnostic(
            ruleId,
            ToolPhase.Test,
            ToolFailureCategory.ProductOrTest,
            MessageFor(ruleId),
            field,
            HintFor(ruleId)));

    private static string HintFor(string ruleId) => ruleId switch
    {
        "HXT001" => "Retain the native TRX report emitted by the selected test platform.",
        "HXT002" => "Supply a readable native TRX report with complete counters.",
        "HXT003" => "Use a filter that matches at least one test.",
        "HXT004" => "Execute at least one non-skipped matching test.",
        "HXT005" => "Resolve failed native test results before recording a pass.",
        "HXT006" => "Resolve the run-level failure before recording a pass.",
        _ => "Correct the native test report before recording a pass.",
    };

    private static string MessageFor(string ruleId) => ruleId switch
    {
        "HXT001" => "A native test report is missing or unreadable.",
        "HXT002" => "A native test report is invalid or has inconsistent counters.",
        "HXT003" => "The selected test filter matched zero tests.",
        "HXT004" => "All matching tests were skipped or not executed.",
        "HXT005" => "The native test report contains failed test results.",
        "HXT006" => "The native test report declares a non-passing run-level outcome.",
        _ => "The native test report cannot represent a pass.",
    };

    private static bool TryReadCounters(
        XElement counters,
        out int total,
        out int passed,
        out int failed,
        out int skipped)
    {
        total = 0;
        passed = 0;
        failed = 0;
        skipped = 0;
        if (!TryReadCounter(counters, "total", true, out total) ||
            !TryReadCounter(counters, "passed", true, out passed) ||
            !TryReadCounter(counters, "failed", true, out int failedCount) ||
            !TryReadCounter(counters, "error", false, out int errors) ||
            !TryReadCounter(counters, "timeout", false, out int timeouts) ||
            !TryReadCounter(counters, "aborted", false, out int aborted) ||
            !TryReadCounter(counters, "notExecuted", false, out int notExecuted) ||
            !TryReadCounter(counters, "inconclusive", false, out int inconclusive))
        {
            return false;
        }

        long failedTotal = (long)failedCount + errors + timeouts + aborted;
        long skippedTotal = (long)notExecuted + inconclusive;
        if (failedTotal > int.MaxValue || skippedTotal > int.MaxValue)
        {
            return false;
        }

        failed = (int)failedTotal;
        skipped = (int)skippedTotal;
        return total >= 0
            && passed >= 0
            && failed >= 0
            && skipped >= 0
            && (long)passed + failed + skipped == total;
    }

    private static bool TryReadCounter(XElement counters, string name, bool required, out int value)
    {
        value = 0;
        XAttribute? attribute = counters.Attributes().FirstOrDefault(attribute =>
            string.Equals(attribute.Name.LocalName, name, StringComparison.Ordinal));
        if (attribute is null)
        {
            return !required;
        }

        // Reject a negative component at the parse boundary: a negative sub-count (e.g. a
        // corrupt "error=-1") could otherwise cancel out a real failure in the aggregate sum
        // check and let a failed run report as passing.
        return int.TryParse(attribute.Value, NumberStyles.Integer, CultureInfo.InvariantCulture, out value)
            && value >= 0;
    }
}