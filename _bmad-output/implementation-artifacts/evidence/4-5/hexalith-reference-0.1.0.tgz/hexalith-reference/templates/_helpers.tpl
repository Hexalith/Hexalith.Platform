{{- define "reference.graph" -}}
{{- required "canonical reference graph is missing" (.Files.Get "reference-graph.json") -}}
{{- end -}}

{{- define "reference.validate" -}}
{{- if not (has .Values.mode (list "normal" "recovery" "remove-workloads")) -}}{{ fail "unknown mode" }}{{- end -}}
{{- if or (lt (int .Values.replicas) 1) (gt (int .Values.replicas) 3) -}}{{ fail "replicas must be 1..3" }}{{- end -}}
{{- range $value := list .Values.imagePullSecret .Values.environment.componentConfigMap .Values.gateway.name .Values.gateway.namespace .Values.gateway.sectionName -}}
{{- if not (regexMatch "^[a-z0-9]([-a-z0-9.]*[a-z0-9])?$" $value) -}}{{ fail "existing credential, ConfigMap and namespaced Gateway references are required" }}{{- end -}}
{{- end -}}
{{- range $value := list .Values.environment.trustDomain .Values.environment.controlPlaneTrustDomain .Values.hostname -}}
{{- if not (regexMatch "^[a-z0-9]([-a-z0-9.]*[a-z0-9])?$" $value) -}}{{ fail "hostname and trust domain are required" }}{{- end -}}
{{- end -}}
{{- range $key, $endpoint := .Values.endpoints -}}
{{- if or (not (regexMatch "^(https|rediss|postgresql)://[a-zA-Z0-9][-a-zA-Z0-9.:/]*$" $endpoint)) (regexMatch "(?i)(localhost|127[.]|0[.]0[.]0[.]0)" $endpoint) -}}{{ fail (printf "unsafe endpoint: %s" $key) }}{{- end -}}
{{- end -}}
{{- $_ := required "existing Sentry endpoint parameter is required" (index .Values.endpoints .Values.environment.sentryEndpoint) -}}
{{- if empty .Values.endpoints -}}{{ fail "non-secret endpoint parameters are required" }}{{- end -}}
{{- $graph := include "reference.graph" . | fromJson -}}
{{- range $graph.capabilities -}}
{{- $binding := required (printf "environment component %s is required" .name) (index $.Values.environment.components .name) -}}
{{- if ne $binding.name .name -}}{{ fail "environment component name differs from graph" }}{{- end -}}
{{- $prefix := index (dict "state" "state." "pubsub" "pubsub." "configuration" "configuration." "secret" "secretstores." "conversation" "conversation.") .kind -}}
{{- if or (not (hasPrefix $prefix (required "hosted component type is required" $binding.type))) (regexMatch "(?i)(local|echo)" $binding.type) -}}{{ fail "component provider differs from capability or is local-only" }}{{- end -}}
{{- range $key := list $binding.endpointMetadataKey $binding.credentialMetadataKey -}}
{{- if not (regexMatch "^[a-zA-Z][a-zA-Z0-9]*$" (toString $key)) -}}{{ fail "provider metadata keys are required" }}{{- end -}}
{{- end -}}
{{- if not (has (default "url" $binding.endpointFormat) (list "url" "authority")) -}}{{ fail "unknown endpoint metadata format" }}{{- end -}}
{{- if and (hasSuffix ".redis" $binding.type) (ne (toString $binding.metadata.enableTLS) "true") -}}{{ fail "hosted Redis bindings require native TLS" }}{{- end -}}
{{- range $key, $value := $binding.metadata -}}
{{- if or (regexMatch "(?i)(password|secret|token|apikey|authorization|connectionstring)" $key) (eq $key $binding.endpointMetadataKey) (eq $key $binding.credentialMetadataKey) -}}{{ fail "provider credentials and endpoints require references" }}{{- end -}}
{{- if regexMatch "(?i)(://|localhost|127[.]|password=|token=)" (toString $value) -}}{{ fail "unsafe provider metadata literal" }}{{- end -}}
{{- end -}}
{{- $endpoint := required "component endpoint reference is required" $binding.endpoint -}}
{{- $_ := required "component endpoint parameter is missing" (index $.Values.endpoints $endpoint) -}}
{{- include "reference.secretRef" $binding.credential | fromYaml | toJson | trunc 0 -}}
{{- end -}}
{{- range $graph.workloads -}}
{{- $w := . -}}
{{- $image := required (printf "image binding missing for %s" .identity) (index $.Values.images .identity) -}}
{{- if not (regexMatch "^[a-z0-9][a-z0-9./_-]*@sha256:[a-f0-9]{64}$" $image) -}}{{ fail "images require repository@sha256 digest; tags are forbidden" }}{{- end -}}
{{- $b := required (printf "bindings missing for %s" .identity) (index $.Values.bindings .identity) -}}
{{- include "reference.secretRef" $b.appToken | fromYaml | toJson | trunc 0 -}}
{{- include "reference.secretRef" $b.apiToken | fromYaml | toJson | trunc 0 -}}
{{- if or (ne $b.appToken.key "token") (ne $b.apiToken.key "token") -}}{{ fail "Dapr token references must use the token key" }}{{- end -}}
{{- range $key, $reference := $b.credentials -}}
{{- if or (not (regexMatch "^[A-Za-z_][A-Za-z0-9_]*$" $key)) (has $key (list "APP_API_TOKEN" "DAPR_API_TOKEN" "ASPNETCORE_URLS" "Dapr__DeclarativeSubscriptions")) (hasKey $w.environment $key) -}}{{ fail "invalid structured credential environment key" }}{{- end -}}
{{- include "reference.secretRef" $reference | fromYaml | toJson | trunc 0 -}}
{{- end -}}
{{- range .inputs -}}
{{- $value := required (printf "%s/%s binding is missing" $w.identity .key) (index $b.configuration .key) -}}
{{- if has .source (list "secret" "dynamic-secret") -}}
{{- include "reference.secretRef" $value | fromYaml | toJson | trunc 0 -}}
{{- if and (hasSuffix ":AppChannelToken" .key) (ne (toJson $value) (toJson $b.appToken)) -}}{{ fail "app channel input must match the shared Dapr token reference" }}{{- end -}}
{{- if and (or (hasSuffix ":DaprApiToken" .key) (hasSuffix ":ApiDaprToken" .key)) (ne (toJson $value) (toJson $b.apiToken)) -}}{{ fail "Dapr API input must match the shared Dapr token reference" }}{{- end -}}
{{- else -}}
{{- if kindIs "map" $value -}}
{{- if hasKey $value "endpoint" -}}
{{- $_ := required "endpoint parameter is missing" (index $.Values.endpoints $value.endpoint) -}}
{{- else if hasKey $value "configMapKeyRef" -}}
{{- include "reference.secretRef" $value.configMapKeyRef | fromYaml | toJson | trunc 0 -}}
{{- else -}}{{ fail "configuration maps must be endpoint or existing ConfigMap references" }}{{- end -}}
{{- else -}}
{{- if regexMatch "(?i)(://|localhost|127[.]0[.]0[.]1|/tmp/|secretsFile|conversation[.]echo|secretstores[.]local|password=|token=|clientsecret|signingkey|authenticationtoken|accesstoken|apikey|privatekey)" (toString $value) -}}{{ fail "unsafe or credential-bearing configuration literal" }}{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "reference.secretRef" -}}
{{- if not (kindIs "map" .) -}}{{ fail "credential literals are forbidden; existing reference required" }}{{- end -}}
{{- if or (ne (len .) 2) (not (hasKey . "name")) (not (hasKey . "key")) -}}{{ fail "existing reference requires only name and key" }}{{- end -}}
{{- if or (not (regexMatch "^[a-z0-9]([-a-z0-9.]*[a-z0-9])?$" (toString .name))) (not (regexMatch "^[-a-zA-Z0-9._]+$" (toString .key))) -}}{{ fail "invalid existing reference name or key" }}{{- end -}}
name: {{ .name | quote }}
key: {{ .key | quote }}
{{- end -}}

{{- define "reference.security" -}}
allowPrivilegeEscalation: false
readOnlyRootFilesystem: true
runAsNonRoot: true
runAsUser: 1654
capabilities:
  drop: [ALL]
seccompProfile:
  type: RuntimeDefault
{{- end -}}

{{- define "reference.dapr" -}}
dapr.io/enabled: "true"
dapr.io/app-id: {{ .workload.appId | quote }}
dapr.io/app-port: "8080"
dapr.io/app-protocol: http
dapr.io/config: {{ printf "platform-%s" .workload.appId | quote }}
dapr.io/app-token-secret: {{ .binding.appToken.name | quote }}
dapr.io/api-token-secret: {{ .binding.apiToken.name | quote }}
dapr.io/sidecar-listen-addresses: "127.0.0.1"
dapr.io/enable-api-logging: "false"
{{- end -}}

{{- define "reference.flatten" -}}
{{- $key := .key -}}
{{- if kindIs "map" .value -}}
{{- range $k, $v := .value -}}{{ include "reference.flatten" (dict "key" (printf "%s__%s" $key $k) "value" $v "environment" $.environment) }}{{- end -}}
{{- else if kindIs "slice" .value -}}
{{- range $k, $v := .value -}}{{ include "reference.flatten" (dict "key" (printf "%s__%d" $key $k) "value" $v "environment" $.environment) }}{{- end -}}
{{- else -}}
{{- $_ := set .environment $key (dict "name" $key "value" (toString .value)) -}}
{{- end -}}
{{- end -}}

{{- define "reference.environment" -}}
{{- $env := dict -}}
{{- $binding := .binding -}}
{{- $root := .root -}}
{{- range .workload.inputs -}}
{{- $value := index $binding.configuration .key -}}
{{- $key := replace ":" "__" .key -}}
{{- if has .source (list "secret" "dynamic-secret") -}}
{{- $_ := set $env $key (dict "name" $key "valueFrom" (dict "secretKeyRef" $value)) -}}
{{- else if kindIs "map" $value -}}
{{- if hasKey $value "endpoint" -}}
{{- $_ := set $env $key (dict "name" $key "value" (index $root.Values.endpoints $value.endpoint)) -}}
{{- else -}}
{{- $_ := set $env $key (dict "name" $key "valueFrom" (dict "configMapKeyRef" $value.configMapKeyRef)) -}}
{{- end -}}
{{- else if or (hasPrefix "[" $value) (hasPrefix "{" $value) -}}
{{- include "reference.flatten" (dict "key" $key "value" (mustFromJson $value) "environment" $env) -}}
{{- else -}}
{{- $_ := set $env $key (dict "name" $key "value" (toString $value)) -}}
{{- end -}}
{{- end -}}
{{- range $key, $reference := $binding.credentials -}}
{{- $_ := set $env $key (dict "name" $key "valueFrom" (dict "secretKeyRef" $reference)) -}}
{{- end -}}
{{- range $key, $value := .workload.environment -}}
{{- $_ := set $env $key (dict "name" $key "value" $value) -}}
{{- end -}}
{{- $_ := set $env "ASPNETCORE_URLS" (dict "name" "ASPNETCORE_URLS" "value" "http://0.0.0.0:8080") -}}
{{- $_ := set $env "Dapr__DeclarativeSubscriptions" (dict "name" "Dapr__DeclarativeSubscriptions" "value" "true") -}}
{{- $_ := set $env "APP_API_TOKEN" (dict "name" "APP_API_TOKEN" "valueFrom" (dict "secretKeyRef" $binding.appToken)) -}}
{{- $_ := set $env "DAPR_API_TOKEN" (dict "name" "DAPR_API_TOKEN" "valueFrom" (dict "secretKeyRef" $binding.apiToken)) -}}
{{- range $key, $value := $env }}
- {{ toYaml $value | nindent 2 | trim }}
{{- end -}}
{{- end -}}
